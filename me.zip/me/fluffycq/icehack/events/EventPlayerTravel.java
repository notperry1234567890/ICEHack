package me.fluffycq.icehack.events;

public class EventPlayerTravel extends ICEEvent {}
