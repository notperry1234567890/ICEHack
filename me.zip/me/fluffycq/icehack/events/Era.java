package me.fluffycq.icehack.events;

public enum Era {
  PRE, PERI, POST;
}
