//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.events;

import me.zero.alpine.type.Cancellable;
import net.minecraft.client.Minecraft;

public class ICEEvent extends Cancellable {
  Era era = Era.PRE;
  
  final float partialTicks;
  
  public ICEEvent() {
    this.partialTicks = Minecraft.getMinecraft().getRenderPartialTicks();
  }
  
  public float getPartialTicks() {
    return this.partialTicks;
  }
  
  public Era getEra() {
    return this.era;
  }
}
