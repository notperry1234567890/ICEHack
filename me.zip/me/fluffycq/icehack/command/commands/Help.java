package me.fluffycq.icehack.command.commands;

import java.util.List;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.command.Command;
import me.fluffycq.icehack.message.Messages;

public class Help extends Command {
  public void handleCommand(String msg, List<String> args) {
    Messages.sendChatMessage("List of available commands in ICEHack:");
    for (Command c : ICEHack.cmdmanager.cmds)
      Messages.sendMessage("&a" + c.cmd + " &7- " + c.desc); 
  }
}
