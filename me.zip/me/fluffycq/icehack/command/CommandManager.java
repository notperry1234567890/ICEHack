package me.fluffycq.icehack.command;

import java.util.ArrayList;
import java.util.List;
import me.fluffycq.icehack.command.commands.Friend;
import me.fluffycq.icehack.command.commands.Help;
import me.fluffycq.icehack.message.Messages;

public class CommandManager {
  public ArrayList<Command> cmds = new ArrayList<>();
  
  public CommandManager() {
    this.cmds.add(new Friend());
    this.cmds.add(new Help());
  }
  
  public void handleCMD(String msg) {
    List<String> args = new ArrayList<>();
    for (String arg : msg.split(" "))
      args.add(arg); 
    if (args.get(0) == null)
      args.add(msg); 
    boolean iscmd = false;
    for (Command c : this.cmds) {
      if (((String)args.get(0)).equalsIgnoreCase(c.getPre()) || c.aliases.contains(((String)args.get(0)).toLowerCase())) {
        c.handleCommand(args.get(0), args);
        iscmd = true;
      } 
    } 
    if (!iscmd)
      Messages.sendChatMessage("&cCommand not found. try 'help' for help."); 
  }
}
