//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.command;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

public class Command {
  public Minecraft mc = Minecraft.getMinecraft();
  
  public String cmd;
  
  public ArrayList<String> aliases = new ArrayList<>();
  
  public String desc;
  
  public List<String> arguments = new ArrayList<>();
  
  public void handleCommand(String msg, List<String> args) {}
  
  public String getPre() {
    return this.cmd;
  }
  
  public boolean argExists(List<String> args, int i) {
    if (args.size() - 1 < i)
      return false; 
    return true;
  }
}
