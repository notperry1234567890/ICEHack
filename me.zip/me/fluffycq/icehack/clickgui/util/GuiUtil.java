//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.clickgui.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class GuiUtil {
  public static FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRenderer;
  
  public FontRenderer fontRenderer() {
    return fontRenderer;
  }
  
  public static void drawCenteredString(String text, int x, int y, int color) {
    fontRenderer.drawStringWithShadow(text, (x - fontRenderer.getStringWidth(text) / 2), y, color);
  }
  
  public static void drawRect(int left, int top, int right, int bottom, int color) {
    if (left < right) {
      int i = left;
      left = right;
      right = i;
    } 
    if (top < bottom) {
      int j = top;
      top = bottom;
      bottom = j;
    } 
    float f3 = (color >> 24 & 0xFF) / 255.0F;
    float f = (color >> 16 & 0xFF) / 255.0F;
    float f1 = (color >> 8 & 0xFF) / 255.0F;
    float f2 = (color & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.getInstance();
    BufferBuilder bufferbuilder = tessellator.getBuffer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
    GlStateManager.color(f, f1, f2, f3);
    bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
    bufferbuilder.pos(left, bottom, 0.0D).endVertex();
    bufferbuilder.pos(right, bottom, 0.0D).endVertex();
    bufferbuilder.pos(right, top, 0.0D).endVertex();
    bufferbuilder.pos(left, top, 0.0D).endVertex();
    tessellator.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  public static void drawHorizontalLine(int startX, int endX, int y, int color) {
    if (endX < startX) {
      int i = startX;
      startX = endX;
      endX = i;
    } 
    drawRect(startX, y, endX + 1, y + 1, color);
  }
  
  public static void drawVerticalLine(int x, int startY, int endY, int color) {
    if (endY < startY) {
      int i = startY;
      startY = endY;
      endY = i;
    } 
    drawRect(x, startY + 1, x + 1, endY, color);
  }
  
  public static void drawString(String text, int x, int y, int color) {
    fontRenderer.drawStringWithShadow(text, x, y, color);
  }
}
