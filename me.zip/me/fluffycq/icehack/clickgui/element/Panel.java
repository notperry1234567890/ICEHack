//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.clickgui.element;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.setting.eSetting;
import me.fluffycq.icehack.clickgui.util.GuiUtil;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class Panel {
  public Minecraft mc = Minecraft.getMinecraft();
  
  public ArrayList<Button> modButtons = new ArrayList<>();
  
  public Category category;
  
  public int x;
  
  public int y;
  
  public int bottomY = 15;
  
  public int cWidth;
  
  public boolean dragging;
  
  public boolean extended;
  
  public String title;
  
  int defaultBG;
  
  ScaledResolution resolution;
  
  public Panel(Category category, int x, int y) {
    this.defaultBG = (new Color(56, 56, 56, 170)).getRGB();
    this.resolution = new ScaledResolution(this.mc);
    this.category = category;
    this.x = x;
    this.y = y;
    this.dragging = false;
    this.extended = true;
    this.title = category.categoryName;
    initWidth();
  }
  
  public void drawPanel(int mouseX, int mouseY) {
    drawCategoryButton();
    for (Button e : this.modButtons)
      e.drawButton(mouseX, mouseY); 
    if (this.dragging) {
      int oldy = this.y;
      this.x = mouseX;
      this.y = mouseY;
      for (Button e : this.modButtons) {
        e.x = this.x;
        e.y += this.y - oldy;
        for (eSetting es : e.settings) {
          es.x = this.x;
          es.y += this.y - oldy;
        } 
      } 
    } 
  }
  
  public void setY(int y) {
    int oldy = this.y;
    this.y = y;
    for (Button e : this.modButtons) {
      e.y += y - oldy;
      for (eSetting es : e.settings)
        es.y += y - oldy; 
    } 
  }
  
  public void initWidth() {
    this.cWidth = 100;
  }
  
  public void addModules() {
    for (Module module : ICEHack.fevents.moduleManager.moduleList) {
      if (module.getCategory().equals(this.category)) {
        this.modButtons.add(new Button(module, this.x, this.y + this.bottomY, this.cWidth, 15, module.name));
        this.bottomY += 15;
      } 
    } 
  }
  
  public void drawCategoryButton() {
    int guiColor;
    if (ICEHack.setmgr.getSettingByMod("Rainbow", ICEHack.fevents.moduleManager.getModule("ClickGUI")).getValBoolean()) {
      guiColor = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F).getRGB();
    } else {
      guiColor = (new Color((int)ICEHack.setmgr.getSettingByName("Red").getValDouble(), (int)ICEHack.setmgr.getSettingByName("Green").getValDouble(), (int)ICEHack.setmgr.getSettingByName("Blue").getValDouble())).getRGB();
    } 
    GuiUtil.drawHorizontalLine(this.x, this.x + this.cWidth - 1, this.y, guiColor);
    GuiUtil.drawHorizontalLine(this.x, this.x + this.cWidth - 1, this.y + 14, guiColor);
    GuiUtil.drawVerticalLine(this.x, this.y + 15, this.y, guiColor);
    GuiUtil.drawVerticalLine(this.x + this.cWidth - 1, this.y + 15, this.y, guiColor);
    GuiUtil.drawRect(this.x + 1, this.y + 1, this.x + this.cWidth - 1, this.y + 14, this.defaultBG);
    GuiUtil.drawCenteredString(this.category.categoryName, this.x + this.cWidth / 2, this.y + 3, -1);
  }
  
  public void toggleExtend() {
    for (Button b : this.modButtons) {
      if (b.visible) {
        this.extended = false;
      } else {
        this.extended = true;
      } 
      b.visible = !b.visible;
    } 
  }
  
  public boolean hoveringCategory(int mouseX, int mouseY) {
    return (mouseX >= this.x && mouseX <= this.x + this.cWidth && mouseY >= this.y && mouseY <= this.y + 15);
  }
  
  public boolean hoveringPanel(int mouseX) {
    return (mouseX >= this.x && mouseX <= this.x + this.cWidth);
  }
  
  public void mouseClicked(int mButton, int mouseX, int mouseY) {
    if (hoveringCategory(mouseX, mouseY) && mButton == 1)
      toggleExtend(); 
    for (Button e : this.modButtons) {
      if (e.isHovering(mouseX, mouseY) && 
        mButton == 1) {
        for (Button button : this.modButtons) {
          if (!e.extended) {
            if (button.y + button.height > e.y + e.height)
              button.y += e.getSettingsSpace(); 
            for (eSetting s : button.settings) {
              if (s.y + s.height > e.y + e.height)
                s.y += e.getSettingsSpace(); 
            } 
            continue;
          } 
          if (button.y + button.height > e.y + e.height)
            button.y -= e.getSettingsSpace(); 
          for (eSetting s : button.settings) {
            if (s.y + s.height > e.y + e.height)
              s.y -= e.getSettingsSpace(); 
          } 
        } 
        e.setExtended(!e.extended);
      } 
    } 
    for (Button b : this.modButtons) {
      if (b.isHovering(mouseX, mouseY) && mButton != 1)
        b.mouseClicked(mButton, mouseX, mouseY); 
      for (eSetting s : b.settings)
        s.mouseClicked(mouseX, mouseY, mButton); 
    } 
    if (hoveringCategory(mouseX, mouseY) && mButton == 0)
      this.dragging = true; 
  }
  
  public void mouseRelease(int mouseX, int mouseY) {
    if (this.dragging == true)
      this.dragging = false; 
    for (Button b : this.modButtons) {
      for (eSetting s : b.settings)
        s.mouseRelease(mouseX, mouseY); 
    } 
    int oldy = this.y;
    this.x = (int)ICEHack.fevents.moduleManager.getModule("ClickGUI").getSetting("Snap X").getValDouble() * Math.round((this.x / (int)ICEHack.fevents.moduleManager.getModule("ClickGUI").getSetting("Snap X").getValDouble()));
    this.y = (int)ICEHack.fevents.moduleManager.getModule("ClickGUI").getSetting("Snap Y").getValDouble() * Math.round((this.y / (int)ICEHack.fevents.moduleManager.getModule("ClickGUI").getSetting("Snap Y").getValDouble()));
    for (Button e : this.modButtons) {
      e.x = this.x;
      e.y += this.y - oldy;
      for (eSetting es : e.settings) {
        es.x = this.x;
        es.y += this.y - oldy;
      } 
    } 
  }
  
  public void keyTyped(char typedChar, int keyCode) throws IOException {
    for (Button b : this.modButtons) {
      for (eSetting s : b.settings)
        s.keyTyped(typedChar, keyCode); 
    } 
  }
}
