//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.clickgui.element;

import java.awt.Color;
import java.util.ArrayList;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.setting.eSetting;
import me.fluffycq.icehack.clickgui.util.GuiUtil;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class Button {
  public Minecraft mc = Minecraft.getMinecraft();
  
  public ArrayList<eSetting> settings = new ArrayList<>();
  
  public Module parent;
  
  public int x;
  
  public int y;
  
  public int width;
  
  public int height;
  
  public String text;
  
  public boolean enabled;
  
  public boolean visible;
  
  public boolean extended;
  
  int idleBG;
  
  public void initSettings() {
    if (ICEHack.setmgr.getSettingsByMod(this.parent) != null)
      for (Setting s : ICEHack.setmgr.getSettingsByMod(this.parent))
        this.settings.add(new eSetting(s, 0, 0, 100, 15));  
  }
  
  public Button(Module parent, int x, int y, int width, int height, String text) {
    this.idleBG = (new Color(84, 84, 84, 170)).getRGB();
    this.parent = parent;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.text = text;
    this.enabled = false;
    this.visible = true;
    this.extended = false;
    initSettings();
  }
  
  public void drawButton(int mouseX, int mouseY) {
    Color guiColor;
    if (ICEHack.setmgr.getSettingByMod("Rainbow", ICEHack.fevents.moduleManager.getModule("ClickGUI")).getValBoolean()) {
      guiColor = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F);
    } else {
      guiColor = new Color((int)ICEHack.setmgr.getSettingByName("Red").getValDouble(), (int)ICEHack.setmgr.getSettingByName("Green").getValDouble(), (int)ICEHack.setmgr.getSettingByName("Blue").getValDouble());
    } 
    if (this.visible) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GuiUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, isToggled() ? guiColor.darker().getRGB() : this.idleBG);
      GuiUtil.drawCenteredString(this.text, this.x + this.width / 2, this.y + (this.height - 8) / 2, -1);
    } 
    if (this.extended && this.visible)
      for (eSetting e : this.settings) {
        if (e.visible)
          e.drawSetting(mouseX, mouseY); 
      }  
  }
  
  public void setExtended(boolean state) {
    this.extended = state;
    if (this.extended) {
      int bottomY = 15;
      for (eSetting e : this.settings) {
        e.x = this.x;
        e.y = this.y + bottomY;
        e.visible = true;
        bottomY += 15;
      } 
    } else {
      for (eSetting e : this.settings) {
        e.x = 0;
        e.y = 0;
        e.visible = false;
      } 
    } 
  }
  
  public int getSettingsSpace() {
    return this.settings.size() * 15;
  }
  
  public boolean isToggled() {
    if (this.parent.getState())
      return true; 
    return false;
  }
  
  public void mouseClicked(int mButton, int mouseX, int mouseY) {
    if (isHovering(mouseX, mouseY) && mButton == 0)
      this.parent.setState(!this.parent.getState()); 
  }
  
  public boolean isHovering(int mouseX, int mouseY) {
    if (!this.visible)
      return false; 
    return (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height);
  }
}
