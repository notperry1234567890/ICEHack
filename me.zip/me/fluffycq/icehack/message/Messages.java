//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.message;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.ITextComponent;

public class Messages {
  public static void sendChatMessage(String message) {
    sendRawChatMessage("&b[ICEHack] &r" + message);
  }
  
  public static void sendMessage(String message) {
    sendRawChatMessage(message);
  }
  
  public static void sendStringChatMessage(String[] messages) {
    sendChatMessage("");
    for (String s : messages)
      sendRawChatMessage(s); 
  }
  
  public static void sendRawChatMessage(String message) {
    (Minecraft.getMinecraft()).player.sendMessage((ITextComponent)new ChatMessage(message));
  }
}
