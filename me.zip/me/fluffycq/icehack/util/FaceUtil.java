//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.util;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;

public class FaceUtil {
  public static Minecraft mc = Minecraft.getMinecraft();
  
  public static float getFacePitch(Entity entityIn) {
    double d1, d0 = entityIn.posX - mc.player.posX;
    double d2 = entityIn.posZ - mc.player.posZ;
    if (entityIn instanceof EntityLivingBase) {
      EntityLivingBase entitylivingbase = (EntityLivingBase)entityIn;
      d1 = entitylivingbase.posY + entitylivingbase.getEyeHeight() - mc.player.posY + mc.player.getEyeHeight();
    } else {
      d1 = ((entityIn.getEntityBoundingBox()).minY + (entityIn.getEntityBoundingBox()).maxY) / 2.0D - mc.player.posY + mc.player.getEyeHeight();
    } 
    double d3 = MathHelper.sqrt(d0 * d0 + d2 * d2);
    float f1 = (float)-(MathHelper.atan2(d1, d3) * 57.29577951308232D);
    return updateRotation(mc.player.rotationPitch, f1, Float.MAX_VALUE);
  }
  
  public static float getFaceYaw(Entity entityIn) {
    double d0 = entityIn.posX - mc.player.posX;
    double d2 = entityIn.posZ - mc.player.posZ;
    if (entityIn instanceof EntityLivingBase) {
      EntityLivingBase entitylivingbase = (EntityLivingBase)entityIn;
      double d1 = entitylivingbase.posY + entitylivingbase.getEyeHeight() - mc.player.posY + mc.player.getEyeHeight();
    } else {
      double d1 = ((entityIn.getEntityBoundingBox()).minY + (entityIn.getEntityBoundingBox()).maxY) / 2.0D - mc.player.posY + mc.player.getEyeHeight();
    } 
    float f = (float)(MathHelper.atan2(d2, d0) * 57.29577951308232D) - 90.0F;
    return updateRotation(mc.player.rotationYaw, f, Float.MAX_VALUE);
  }
  
  private static float updateRotation(float angle, float targetAngle, float maxIncrease) {
    float f = MathHelper.wrapDegrees(targetAngle - angle);
    if (f > maxIncrease)
      f = maxIncrease; 
    if (f < -maxIncrease)
      f = -maxIncrease; 
    return angle + f;
  }
  
  public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer player) {
    double dirx = player.posX - px;
    double diry = player.posY - py;
    double dirz = player.posZ - pz;
    double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
    dirx /= len;
    diry /= len;
    dirz /= len;
    double pitch = Math.asin(diry);
    double yaw = Math.atan2(dirz, dirx);
    pitch = pitch * 180.0D / Math.PI;
    yaw = yaw * 180.0D / Math.PI;
    yaw += 90.0D;
    return new double[] { yaw, pitch };
  }
}
