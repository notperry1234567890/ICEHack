package me.fluffycq.icehack.util;

public class ColorUtil {
  public static String getColor(String bColor) {
    String uColor = "";
    switch (bColor) {
      case "&0":
        uColor = "§0";
        break;
      case "&1":
        uColor = "§1";
        break;
      case "&2":
        uColor = "§2";
        break;
      case "&3":
        uColor = "§3";
        break;
      case "&4":
        uColor = "§4";
        break;
      case "&5":
        uColor = "§5";
        break;
      case "&6":
        uColor = "§6";
        break;
      case "&7":
        uColor = "§7";
        break;
      case "&8":
        uColor = "§8";
        break;
      case "&9":
        uColor = "§9";
        break;
      case "&a":
        uColor = "§a";
        break;
      case "&b":
        uColor = "§b";
        break;
      case "&c":
        uColor = "§c";
        break;
      case "&d":
        uColor = "§d";
        break;
      case "&e":
        uColor = "§e";
        break;
      case "&f":
        uColor = "§f";
        break;
    } 
    return uColor;
  }
}
