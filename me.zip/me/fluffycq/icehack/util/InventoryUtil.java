//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.util;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class InventoryUtil {
  static Minecraft mc = Minecraft.getMinecraft();
  
  public static int getItem(Item i) {
    if (mc.player == null)
      return -1; 
    for (int x = 0; x < mc.player.inventoryContainer.getInventory().size(); x++) {
      if (x != 0 && x != 5 && x != 6 && x != 7 && x != 8) {
        ItemStack s = (ItemStack)mc.player.inventoryContainer.getInventory().get(x);
        if (!s.isEmpty() && 
          s.getItem().equals(i))
          return x; 
      } 
    } 
    return -1;
  }
}
