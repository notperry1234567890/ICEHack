//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.util;

import java.util.HashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class ICERenderer extends Tessellator {
  public static ICERenderer INSTANCE = new ICERenderer();
  
  public ICERenderer() {
    super(2097152);
  }
  
  public static void prepare(int mode) {
    prepareGL();
    begin(mode);
  }
  
  public static void prepareGL() {
    GL11.glBlendFunc(770, 771);
    GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
    GlStateManager.glLineWidth(1.5F);
    GlStateManager.disableTexture2D();
    GlStateManager.depthMask(false);
    GlStateManager.enableBlend();
    GlStateManager.disableDepth();
    GlStateManager.disableLighting();
    GlStateManager.disableCull();
    GlStateManager.enableAlpha();
    GlStateManager.color(1.0F, 1.0F, 1.0F);
  }
  
  public static void begin(int mode) {
    INSTANCE.getBuffer().begin(mode, DefaultVertexFormats.POSITION_COLOR);
  }
  
  public static void release() {
    render();
    releaseGL();
  }
  
  public static void render() {
    INSTANCE.draw();
  }
  
  public static void releaseGL() {
    GlStateManager.enableCull();
    GlStateManager.depthMask(true);
    GlStateManager.enableTexture2D();
    GlStateManager.enableBlend();
    GlStateManager.enableDepth();
  }
  
  public static void drawBox(BlockPos blockPos, int argb, int sides) {
    int a = argb >>> 24 & 0xFF;
    int r = argb >>> 16 & 0xFF;
    int g = argb >>> 8 & 0xFF;
    int b = argb & 0xFF;
    drawBox(blockPos, r, g, b, a, sides);
  }
  
  public static void drawBoxOpacity(BlockPos blockPos, int argb, int opacity, int sides) {
    int a = opacity;
    int r = argb >>> 16 & 0xFF;
    int g = argb >>> 8 & 0xFF;
    int b = argb & 0xFF;
    drawBox(blockPos, r, g, b, a, sides);
  }
  
  public static void drawBox(float x, float y, float z, int argb, int sides) {
    int a = argb >>> 24 & 0xFF;
    int r = argb >>> 16 & 0xFF;
    int g = argb >>> 8 & 0xFF;
    int b = argb & 0xFF;
    drawBox(INSTANCE.getBuffer(), x, y, z, 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
  }
  
  public static void drawBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
    drawBox(INSTANCE.getBuffer(), blockPos.x, blockPos.y, blockPos.z, 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
  }
  
  public static void drawBox(BlockPos blockPos, int r, int g, int b, int a, float width, int sides) {
    drawBox(INSTANCE.getBuffer(), blockPos.x, blockPos.y, blockPos.z, width, 1.0F, 1.0F, r, g, b, a, sides);
  }
  
  public static BufferBuilder getBufferBuilder() {
    return INSTANCE.getBuffer();
  }
  
  public static void drawBox(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
    if ((sides & 0x1) != 0) {
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x2) != 0) {
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x4) != 0) {
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x8) != 0) {
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x10) != 0) {
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x20) != 0) {
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
  }
  
  public static void drawLines(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
    if ((sides & 0x11) != 0) {
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x12) != 0) {
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x21) != 0) {
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x22) != 0) {
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x5) != 0) {
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x6) != 0) {
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x9) != 0) {
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0xA) != 0) {
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x14) != 0) {
      buffer.pos(x, y, z).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x24) != 0) {
      buffer.pos((x + w), y, z).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), z).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x18) != 0) {
      buffer.pos(x, y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos(x, (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
    if ((sides & 0x28) != 0) {
      buffer.pos((x + w), y, (z + d)).color(r, g, b, a).endVertex();
      buffer.pos((x + w), (y + h), (z + d)).color(r, g, b, a).endVertex();
    } 
  }
  
  public static void drawBoundingBoxBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
    GlStateManager.pushMatrix();
    GlStateManager.enableBlend();
    GlStateManager.disableDepth();
    GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
    GlStateManager.disableTexture2D();
    GlStateManager.depthMask(false);
    GL11.glEnable(2848);
    GL11.glHint(3154, 4354);
    GL11.glLineWidth(width);
    Minecraft mc = Minecraft.getMinecraft();
    double x = bp.x - (mc.getRenderManager()).viewerPosX;
    double y = bp.y - (mc.getRenderManager()).viewerPosY;
    double z = bp.z - (mc.getRenderManager()).viewerPosZ;
    AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
    Tessellator tessellator = Tessellator.getInstance();
    BufferBuilder bufferbuilder = tessellator.getBuffer();
    bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
    bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    tessellator.draw();
    bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
    bufferbuilder.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.maxY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.maxY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.maxY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, alpha).endVertex();
    tessellator.draw();
    bufferbuilder.begin(1, DefaultVertexFormats.POSITION_COLOR);
    bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.maxY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.maxY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.maxY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.maxY, bb.maxZ).color(r, g, b, alpha).endVertex();
    tessellator.draw();
    GL11.glDisable(2848);
    GlStateManager.depthMask(true);
    GlStateManager.enableDepth();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
    GlStateManager.popMatrix();
  }
  
  public static void drawBoundingBoxBottomBlockPos(BlockPos bp, float width, int r, int g, int b, int alpha) {
    GlStateManager.pushMatrix();
    GlStateManager.enableBlend();
    GlStateManager.disableDepth();
    GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
    GlStateManager.disableTexture2D();
    GlStateManager.depthMask(false);
    GL11.glEnable(2848);
    GL11.glHint(3154, 4354);
    GL11.glLineWidth(width);
    Minecraft mc = Minecraft.getMinecraft();
    double x = bp.x - (mc.getRenderManager()).viewerPosX;
    double y = bp.y - (mc.getRenderManager()).viewerPosY;
    double z = bp.z - (mc.getRenderManager()).viewerPosZ;
    AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
    Tessellator tessellator = Tessellator.getInstance();
    BufferBuilder bufferbuilder = tessellator.getBuffer();
    bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
    bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.minX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.maxZ).color(r, g, b, alpha).endVertex();
    bufferbuilder.pos(bb.maxX, bb.minY, bb.minZ).color(r, g, b, alpha).endVertex();
    tessellator.draw();
    GL11.glDisable(2848);
    GlStateManager.depthMask(true);
    GlStateManager.enableDepth();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
    GlStateManager.popMatrix();
  }
  
  public static final HashMap<EnumFacing, Integer> FACEMAP = new HashMap<>();
  
  static {
    FACEMAP.put(EnumFacing.DOWN, Integer.valueOf(1));
    FACEMAP.put(EnumFacing.WEST, Integer.valueOf(16));
    FACEMAP.put(EnumFacing.NORTH, Integer.valueOf(4));
    FACEMAP.put(EnumFacing.SOUTH, Integer.valueOf(8));
    FACEMAP.put(EnumFacing.EAST, Integer.valueOf(32));
    FACEMAP.put(EnumFacing.UP, Integer.valueOf(2));
  }
  
  public static final class Quad {
    public static final int DOWN = 1;
    
    public static final int UP = 2;
    
    public static final int NORTH = 4;
    
    public static final int SOUTH = 8;
    
    public static final int WEST = 16;
    
    public static final int EAST = 32;
    
    public static final int ALL = 63;
  }
  
  public static final class Line {
    public static final int DOWN_WEST = 17;
    
    public static final int UP_WEST = 18;
    
    public static final int DOWN_EAST = 33;
    
    public static final int UP_EAST = 34;
    
    public static final int DOWN_NORTH = 5;
    
    public static final int UP_NORTH = 6;
    
    public static final int DOWN_SOUTH = 9;
    
    public static final int UP_SOUTH = 10;
    
    public static final int NORTH_WEST = 20;
    
    public static final int NORTH_EAST = 36;
    
    public static final int SOUTH_WEST = 24;
    
    public static final int SOUTH_EAST = 40;
    
    public static final int ALL = 63;
  }
}
