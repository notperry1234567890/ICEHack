package me.fluffycq.icehack.util;

import java.lang.reflect.Field;
import org.lwjgl.input.Keyboard;

public class KeyUtil {
  public static int getKeyCode(String keyName) {
    Class<Keyboard> keys = Keyboard.class;
    int keyCode = -69;
    try {
      Field key = keys.getField(keyName);
      keyCode = key.getInt(null);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (NoSuchFieldException e) {
      e.printStackTrace();
    } 
    return keyCode;
  }
}
