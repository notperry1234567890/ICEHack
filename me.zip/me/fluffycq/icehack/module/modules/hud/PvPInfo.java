//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.hud;

import java.awt.Color;
import java.util.ArrayList;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.frame.Frame;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class PvPInfo extends Module {
  public Setting totemcount;
  
  public Setting crystalcount;
  
  public Setting xpcount;
  
  public Setting gapcount;
  
  public Setting obicount;
  
  public Setting red;
  
  public Setting green;
  
  public Setting blue;
  
  public Setting redinfo;
  
  public Setting greeninfo;
  
  public Setting blueinfo;
  
  public Setting rainbow;
  
  public Setting pixelwidth;
  
  int color;
  
  int infocolor;
  
  ScaledResolution resolution;
  
  ArrayList<String> info;
  
  Frame frame;
  
  public PvPInfo() {
    super("PvPInfo", 0, Category.HUD);
    this.resolution = new ScaledResolution(mc);
    this.info = new ArrayList<>();
    this.rainbow = new Setting("Rainbow", this, false);
    this.totemcount = new Setting("Totems", this, true);
    this.crystalcount = new Setting("Crystals", this, true);
    this.gapcount = new Setting("Gapples", this, true);
    this.xpcount = new Setting("XP", this, true);
    this.obicount = new Setting("Obi", this, true);
    this.pixelwidth = new Setting("PixelWidth", this, 1.0D, 1.0D, 10.0D, true);
    this.red = new Setting("Red", this, 255.0D, 3.0D, 255.0D, true);
    this.green = new Setting("Green", this, 26.0D, 3.0D, 255.0D, true);
    this.blue = new Setting("Blue", this, 42.0D, 3.0D, 255.0D, true);
    this.redinfo = new Setting("Count Red", this, 255.0D, 3.0D, 255.0D, true);
    this.greeninfo = new Setting("Count Green", this, 26.0D, 3.0D, 255.0D, true);
    this.blueinfo = new Setting("Count Blue", this, 42.0D, 3.0D, 255.0D, true);
  }
  
  public void onRender() {
    initSetting(this.totemcount);
    initSetting(this.crystalcount);
    initSetting(this.gapcount);
    initSetting(this.obicount);
    initSetting(this.xpcount);
    if (this.rainbow.getValBoolean()) {
      this.color = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F).getRGB();
    } else {
      this.color = (new Color((int)this.red.getValDouble(), (int)this.green.getValDouble(), (int)this.blue.getValDouble())).getRGB();
    } 
    this.infocolor = (new Color((int)this.redinfo.getValDouble(), (int)this.greeninfo.getValDouble(), (int)this.blueinfo.getValDouble())).getRGB();
    this.frame = ICEHack.clickgui.frames.get(1);
    if (this.frame.extended) {
      if (this.rainbow.getValBoolean()) {
        this.color = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F).getRGB();
      } else {
        this.color = (new Color((int)this.red.getValDouble(), (int)this.green.getValDouble(), (int)this.blue.getValDouble())).getRGB();
      } 
      this.infocolor = (new Color((int)this.redinfo.getValDouble(), (int)this.greeninfo.getValDouble(), (int)this.blueinfo.getValDouble())).getRGB();
      if (this.frame.x + 100 <= this.resolution.getScaledWidth() / 2 + 100) {
        int textY = this.frame.y + 15;
        for (String s : this.info) {
          int count = 0;
          for (int i = 0; i < 45; i++) {
            ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
            if (itemStack.getItem().equals(getItem(s)) && s.equalsIgnoreCase("Gapple") && itemStack.getItemDamage() == 1)
              count += itemStack.stackSize; 
            if (itemStack.getItem().equals(getItem(s)) && !s.equalsIgnoreCase("Gapple"))
              count += itemStack.stackSize; 
          } 
          mc.fontRenderer.drawStringWithShadow(s, this.frame.x, textY, this.color);
          mc.fontRenderer.drawStringWithShadow(String.valueOf(count), (this.frame.x + mc.fontRenderer.getStringWidth(s) + (int)this.pixelwidth.getValDouble()), textY, this.infocolor);
          textY += 10;
        } 
      } 
      if (this.frame.x + 100 >= this.resolution.getScaledWidth() / 2 + 100) {
        int textY = this.frame.y + 15;
        for (String s : this.info) {
          int count = 0;
          for (int i = 0; i < 45; i++) {
            ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
            if (itemStack.getItem().equals(getItem(s)) && s.equalsIgnoreCase("Gapple") && itemStack.getItemDamage() == 1)
              count += itemStack.stackSize; 
            if (itemStack.getItem().equals(getItem(s)) && !s.equalsIgnoreCase("Gapple"))
              count += itemStack.stackSize; 
          } 
          int baseX = this.frame.x + 100 - mc.fontRenderer.getStringWidth(s) - (int)this.pixelwidth.getValDouble() - mc.fontRenderer.getStringWidth(String.valueOf(count));
          mc.fontRenderer.drawStringWithShadow(s, baseX, textY, this.color);
          mc.fontRenderer.drawStringWithShadow(String.valueOf(count), (baseX + mc.fontRenderer.getStringWidth(s) + (int)this.pixelwidth.getValDouble()), textY, this.infocolor);
          textY += 10;
        } 
      } 
    } 
  }
  
  public void initSetting(Setting set) {
    if (!this.info.contains(set.getName()) && set.getValBoolean())
      this.info.add(set.getName()); 
    if (this.info.contains(set.getName()) && !set.getValBoolean())
      this.info.remove(set.getName()); 
  }
  
  public Item getItem(String name) {
    Item item = null;
    switch (name) {
      case "Totems":
        item = Items.TOTEM_OF_UNDYING;
        break;
      case "Crystals":
        item = Items.END_CRYSTAL;
        break;
      case "Gapples":
        item = Items.GOLDEN_APPLE;
        break;
      case "Obi":
        item = Item.getItemFromBlock(Blocks.OBSIDIAN);
        break;
      case "XP":
        item = Items.EXPERIENCE_BOTTLE;
        break;
    } 
    return item;
  }
}
