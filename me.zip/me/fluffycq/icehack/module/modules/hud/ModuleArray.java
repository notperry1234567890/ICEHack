//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.frame.Frame;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.client.gui.ScaledResolution;

public class ModuleArray extends Module {
  public Setting topline;
  
  public Setting rainbow;
  
  public Setting red;
  
  public Setting green;
  
  public Setting blue;
  
  public Setting redinfo;
  
  public Setting greeninfo;
  
  public Setting blueinfo;
  
  public Setting v;
  
  public ArrayList<String> hArrangement = new ArrayList<>();
  
  public ArrayList<String> vArrangement = new ArrayList<>();
  
  ScaledResolution resolution;
  
  Frame frame;
  
  ArrayList<Module> enabled;
  
  int color;
  
  int infocolor;
  
  public ModuleArray() {
    super("ArrayList", 0, Category.HUD);
    this.resolution = new ScaledResolution(mc);
    this.enabled = new ArrayList<>();
    this.rainbow = new Setting("Rainbow", this, false);
    this.red = new Setting("Red", this, 255.0D, 3.0D, 255.0D, true);
    this.green = new Setting("Green", this, 26.0D, 3.0D, 255.0D, true);
    this.blue = new Setting("Blue", this, 42.0D, 3.0D, 255.0D, true);
    this.redinfo = new Setting("Info Red", this, 255.0D, 3.0D, 255.0D, true);
    this.greeninfo = new Setting("Info Green", this, 26.0D, 3.0D, 255.0D, true);
    this.blueinfo = new Setting("Info Blue", this, 42.0D, 3.0D, 255.0D, true);
    this.hArrangement.add("Left");
    this.hArrangement.add("Right");
    this.vArrangement.add("Up");
    this.vArrangement.add("Down");
    this.v = new Setting("Array V", this, "Down", this.vArrangement);
  }
  
  public void onEnable() {
    for (Module mod : ICEHack.fevents.moduleManager.moduleList) {
      if (this.enabled.contains(mod) && (mod.isDisabled() || !mod.isVisible())) {
        this.enabled.remove(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
      if (!this.enabled.contains(mod) && mod.isEnabled() && !mod.getCategory().equals(Category.HUD) && mod.isVisible()) {
        this.enabled.add(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
    } 
  }
  
  public void onDisable() {
    for (Module mod : ICEHack.fevents.moduleManager.moduleList) {
      if (this.enabled.contains(mod) && (mod.isDisabled() || !mod.isVisible())) {
        this.enabled.remove(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
      if (!this.enabled.contains(mod) && mod.isEnabled() && !mod.getCategory().equals(Category.HUD) && mod.isVisible()) {
        this.enabled.add(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
    } 
  }
  
  public void onRender() {
    for (Module mod : ICEHack.fevents.moduleManager.moduleList) {
      if (this.enabled.contains(mod) && (mod.isDisabled() || !mod.isVisible())) {
        this.enabled.remove(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
      if (!this.enabled.contains(mod) && mod.isEnabled() && !mod.getCategory().equals(Category.HUD) && mod.isVisible()) {
        this.enabled.add(mod);
        Comparator<Module> lengthComp = new Comparator<Module>() {
            public int compare(Module o1, Module o2) {
              return Integer.compare(o2.getName().length() + o2.getModInfo().length(), o1.getName().length() + o1.getModInfo().length());
            }
          };
        Collections.sort(this.enabled, lengthComp);
      } 
    } 
    this.frame = ICEHack.clickgui.frames.get(0);
    if (this.frame.extended) {
      if (this.rainbow.getValBoolean()) {
        this.color = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F).getRGB();
      } else {
        this.color = (new Color((int)this.red.getValDouble(), (int)this.green.getValDouble(), (int)this.blue.getValDouble())).getRGB();
      } 
      this.infocolor = (new Color((int)this.redinfo.getValDouble(), (int)this.greeninfo.getValDouble(), (int)this.blueinfo.getValDouble())).getRGB();
      if (this.frame.x + 100 <= this.resolution.getScaledWidth() / 2 + 100) {
        int textY = this.frame.y + 15;
        if (this.v.getValString().equalsIgnoreCase("Up")) {
          for (int i = this.enabled.size() - 1; i >= 0; i--) {
            mc.fontRenderer.drawStringWithShadow(((Module)this.enabled.get(i)).getName(), this.frame.x, textY, this.color);
            mc.fontRenderer.drawStringWithShadow(((Module)this.enabled.get(i)).getModInfo(), (this.frame.x + 2 + mc.fontRenderer.getStringWidth(((Module)this.enabled.get(i)).getName())), textY, this.infocolor);
            textY += 10;
          } 
        } else if (this.v.getValString().equalsIgnoreCase("Down")) {
          for (Module s : this.enabled) {
            mc.fontRenderer.drawStringWithShadow(s.getName(), this.frame.x, textY, this.color);
            mc.fontRenderer.drawStringWithShadow(s.getModInfo(), (this.frame.x + 2 + mc.fontRenderer.getStringWidth(s.getName())), textY, this.infocolor);
            textY += 10;
          } 
        } 
      } 
      if (this.frame.x + 100 >= this.resolution.getScaledWidth() / 2 + 100) {
        int textY = this.frame.y + 15;
        if (this.v.getValString().equalsIgnoreCase("Up")) {
          for (int i = this.enabled.size() - 1; i >= 0; i--) {
            int baseX = this.frame.x + 100 - mc.fontRenderer.getStringWidth(((Module)this.enabled.get(i)).getName()) - 2 - mc.fontRenderer.getStringWidth(((Module)this.enabled.get(i)).getModInfo());
            mc.fontRenderer.drawStringWithShadow(((Module)this.enabled.get(i)).getName(), baseX, textY, this.color);
            mc.fontRenderer.drawStringWithShadow(((Module)this.enabled.get(i)).getModInfo(), (baseX + mc.fontRenderer.getStringWidth(((Module)this.enabled.get(i)).getName()) + 2), textY, this.infocolor);
            textY += 10;
          } 
        } else if (this.v.getValString().equalsIgnoreCase("Down")) {
          for (Module s : this.enabled) {
            int baseX = this.frame.x + 100 - mc.fontRenderer.getStringWidth(s.getName()) - 2 - mc.fontRenderer.getStringWidth(s.getModInfo());
            mc.fontRenderer.drawStringWithShadow(s.getName(), baseX, textY, this.color);
            mc.fontRenderer.drawStringWithShadow(s.getModInfo(), (baseX + mc.fontRenderer.getStringWidth(s.getName()) + 2), textY, this.infocolor);
            textY += 10;
          } 
        } 
      } 
    } 
  }
}
