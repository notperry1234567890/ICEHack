package me.fluffycq.icehack.module.modules.render;

import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;

public class ShulkerViewer extends Module {
  public Setting opacity;
  
  public Setting r;
  
  public Setting g;
  
  public Setting b;
  
  public ShulkerViewer() {
    super("ShulkerViewer", 0, Category.RENDER);
    this.opacity = new Setting("Opacity", this, 200.0D, 5.0D, 255.0D, true);
    this.r = new Setting("Red", this, 200.0D, 5.0D, 255.0D, true);
    this.g = new Setting("Green", this, 200.0D, 5.0D, 255.0D, true);
    this.b = new Setting("Blue", this, 200.0D, 5.0D, 255.0D, true);
  }
}
