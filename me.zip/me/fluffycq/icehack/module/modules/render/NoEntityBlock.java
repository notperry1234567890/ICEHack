//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.render;

import java.util.ArrayList;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.util.math.RayTraceResult;

public class NoEntityBlock extends Module {
  static NoEntityBlock INST;
  
  public Setting mode;
  
  public ArrayList<String> modes = new ArrayList<>();
  
  public NoEntityBlock() {
    super("NoEntityBlock", 0, Category.RENDER);
    INST = this;
    this.modes.add("Normal");
    this.modes.add("Dev");
    this.mode = new Setting("Mode", this, "Normal", this.modes);
  }
  
  public static boolean doBlock() {
    if (INST.mode.getValString().equalsIgnoreCase("Normal")) {
      if (mc.objectMouseOver != null)
        return (INST.isEnabled() && mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemPickaxe && mc.objectMouseOver.getBlockPos() != null); 
      return false;
    } 
    if (INST.mode.getValString().equalsIgnoreCase("Dev")) {
      if (mc.objectMouseOver != null) {
        if (mc.objectMouseOver.typeOfHit != null)
          return (INST.isEnabled() && mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemPickaxe && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK); 
        return false;
      } 
      return false;
    } 
    return false;
  }
}
