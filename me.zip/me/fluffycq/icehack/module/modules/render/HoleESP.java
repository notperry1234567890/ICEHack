//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import me.fluffycq.icehack.events.RenderEvent;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.module.modules.combat.AutoCrystal;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.ICERenderer;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class HoleESP extends Module {
  public static BlockPos getPlayerPos() {
    return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
  }
  
  private final BlockPos[] surroundOffset = new BlockPos[] { new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0) };
  
  public Setting renderDist;
  
  public Setting a0;
  
  public Setting r1;
  
  public Setting g1;
  
  public Setting b1;
  
  public Setting r2;
  
  public Setting g2;
  
  public Setting b2;
  
  public Setting mode;
  
  public Setting width;
  
  ArrayList<String> options = new ArrayList<>();
  
  private ConcurrentHashMap<BlockPos, Boolean> safeHoles;
  
  public HoleESP() {
    super("HoleESP", 0, Category.RENDER);
    this.renderDist = new Setting("Distance", this, 10.0D, 1.0D, 20.0D, false);
    this.a0 = new Setting("Opacity", this, 75.0D, 5.0D, 255.0D, false);
    this.r1 = new Setting("Obi Red", this, 255.0D, 5.0D, 255.0D, true);
    this.g1 = new Setting("Obi Green", this, 255.0D, 5.0D, 255.0D, true);
    this.b1 = new Setting("Obi Blue", this, 255.0D, 5.0D, 255.0D, true);
    this.r2 = new Setting("Bedrock R", this, 255.0D, 5.0D, 255.0D, true);
    this.g2 = new Setting("Bedrock G", this, 255.0D, 5.0D, 255.0D, true);
    this.b2 = new Setting("Bedrock B", this, 255.0D, 5.0D, 255.0D, true);
    this.width = new Setting("Width", this, 1.0D, 1.0D, 10.0D, false);
    this.options.add("Full");
    this.options.add("Down");
    this.options.add("Outline");
    this.mode = new Setting("Mode", this, "Full", this.options);
  }
  
  private enum RenderMode {
    DOWN, BLOCK;
  }
  
  private enum RenderBlocks {
    OBBY, BEDROCK, BOTH;
  }
  
  public void onUpdate() {
    if (this.safeHoles == null) {
      this.safeHoles = new ConcurrentHashMap<>();
    } else {
      this.safeHoles.clear();
    } 
    int range = (int)Math.ceil(this.renderDist.getValDouble());
    List<BlockPos> blockPosList = AutoCrystal.getSphere(getPlayerPos(), range, range, false, true, 0);
    for (BlockPos pos : blockPosList) {
      if (!mc.world.getBlockState(pos).getBlock().equals(Blocks.AIR))
        continue; 
      if (!mc.world.getBlockState(pos.add(0, 1, 0)).getBlock().equals(Blocks.AIR))
        continue; 
      if (!mc.world.getBlockState(pos.add(0, 2, 0)).getBlock().equals(Blocks.AIR))
        continue; 
      boolean isSafe = true;
      boolean isBedrock = true;
      for (BlockPos offset : this.surroundOffset) {
        Block block = mc.world.getBlockState(pos.add((Vec3i)offset)).getBlock();
        if (block != Blocks.BEDROCK)
          isBedrock = false; 
        if (block != Blocks.BEDROCK && block != Blocks.OBSIDIAN && block != Blocks.ENDER_CHEST && block != Blocks.ANVIL) {
          isSafe = false;
          break;
        } 
      } 
      if (isSafe)
        this.safeHoles.put(pos, Boolean.valueOf(isBedrock)); 
    } 
  }
  
  public void onWorld(RenderEvent event) {
    if (mc.player == null || this.safeHoles == null)
      return; 
    if (this.safeHoles.isEmpty())
      return; 
    ICERenderer.prepare(7);
    this.safeHoles.forEach((blockPos, isBedrock) -> {
          if (isBedrock.booleanValue()) {
            drawBox(blockPos, (int)this.r2.getValDouble(), (int)this.g2.getValDouble(), (int)this.b2.getValDouble());
          } else {
            drawBox(blockPos, (int)this.r1.getValDouble(), (int)this.g1.getValDouble(), (int)this.b1.getValDouble());
          } 
        });
    ICERenderer.release();
  }
  
  private void drawBox(BlockPos blockPos, int r, int g, int b) {
    Color color = new Color(r, g, b, (int)this.a0.getValDouble());
    if (this.mode.getValString().equals("Down")) {
      ICERenderer.drawBox(blockPos, color.getRGB(), 1);
    } else if (this.mode.getValString().equals("Full")) {
      ICERenderer.drawBox(blockPos, color.getRGB(), 63);
    } else if (this.mode.getValString().equals("Outline")) {
      ICERenderer.drawBoundingBoxBottomBlockPos(blockPos, (float)this.width.getValDouble(), r, g, b, (int)this.a0.getValDouble());
    } 
  }
}
