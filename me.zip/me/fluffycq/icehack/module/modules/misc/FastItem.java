//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.misc;

import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.math.BlockPos;

public class FastItem extends Module {
  public Setting delay;
  
  public Setting xp;
  
  public Setting bow;
  
  public FastItem() {
    super("FastItem", 0, Category.MISC);
    this.delay = new Setting("Delay", this, 1.0D, 0.0D, 20.0D, true);
    this.xp = new Setting("XP", this, true);
    this.bow = new Setting("Bow", this, true);
  }
  
  private static long tick = 0L;
  
  public void onUpdate() {
    if (this.bow.getValBoolean() && isHolding((Item)Items.BOW) && mc.player.isHandActive() && mc.player.getItemInUseMaxCount() >= 3) {
      mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
      mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(mc.player.getActiveHand()));
      mc.player.stopActiveHand();
    } 
    if (this.delay.getValDouble() > 0.0D)
      if (tick <= 0L) {
        tick = Math.round((2 * Math.round((float)this.delay.getValDouble() / 2.0F)));
      } else {
        tick--;
        mc.rightClickDelayTimer = 1;
        return;
      }  
    if (isHolding(Items.EXPERIENCE_BOTTLE) && this.xp.getValBoolean())
      mc.rightClickDelayTimer = 0; 
  }
  
  public boolean isHolding(Item i) {
    return mc.player.getHeldItemMainhand().getItem().equals(i);
  }
}
