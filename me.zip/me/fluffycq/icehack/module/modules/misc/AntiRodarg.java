//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.misc;

import me.fluffycq.icehack.events.PacketEvent;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.client.FMLClientHandler;

public class AntiRodarg extends Module {
  @EventHandler
  private Listener<PacketEvent.Receive> recListener;
  
  public AntiRodarg() {
    super("AntiRodarg", 0, Category.MISC);
    this.recListener = new Listener(event -> {
          if (event.getPacket() instanceof SPacketPlayerListItem && ((SPacketPlayerListItem)event.getPacket()).getAction() == SPacketPlayerListItem.Action.ADD_PLAYER) {
            SPacketPlayerListItem packet = (SPacketPlayerListItem)event.getPacket();
            for (SPacketPlayerListItem.AddPlayerData data : packet.getEntries()) {
              String player = (data.getProfile() != null) ? data.getProfile().getName() : "null";
              if (player.equalsIgnoreCase("Rodarg"))
                FMLClientHandler.instance().getClientToServerNetworkManager().closeChannel((ITextComponent)new TextComponentString("REMO IS COMING!!! HIDE YOUR BASES!")); 
            } 
          } 
        }new java.util.function.Predicate[0]);
  }
}
