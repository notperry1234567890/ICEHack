//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.misc;

import java.util.HashMap;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.events.PacketEvent;
import me.fluffycq.icehack.events.PopTotemEvent;
import me.fluffycq.icehack.message.Messages;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.world.World;

public class TotemPopAlert extends Module {
  public Setting cName;
  
  HashMap<String, Integer> popped = new HashMap<>();
  
  @EventHandler
  public Listener<PopTotemEvent> popEvent;
  
  @EventHandler
  public Listener<PacketEvent.Receive> totemPopListener;
  
  public TotemPopAlert() {
    super("TotemPopAlert", 0, Category.MISC);
    this.popEvent = new Listener(event -> {
          if (this.popped == null)
            this.popped = new HashMap<>(); 
          if (this.popped.get(event.getEntity().getName()) == null) {
            this.popped.put(event.getEntity().getName(), Integer.valueOf(1));
            sendMessage("&3" + event.getEntity().getName() + " &4popped &61 totem");
          } else if (this.popped.get(event.getEntity().getName()) != null) {
            int popCounter = ((Integer)this.popped.get(event.getEntity().getName())).intValue();
            int newPopCounter = ++popCounter;
            this.popped.put(event.getEntity().getName(), Integer.valueOf(newPopCounter));
            sendMessage("&3" + event.getEntity().getName() + " &4popped &6" + String.valueOf(newPopCounter) + " totems");
          } 
        }new java.util.function.Predicate[0]);
    this.totemPopListener = new Listener(event -> {
          if (mc.world == null || mc.player == null)
            return; 
          if (isEnabled() && event.getPacket() instanceof SPacketEntityStatus && ((SPacketEntityStatus)event.getPacket()).getOpCode() == 35) {
            Entity entity = ((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world);
            ICEHack.EVENT_BUS.post(new PopTotemEvent(entity));
          } 
        }new java.util.function.Predicate[0]);
    this.cName = new Setting("ICEHack", this, true);
  }
  
  public void onEnable() {
    this.popped.clear();
  }
  
  public void onUpdate() {
    for (EntityPlayer player : mc.world.playerEntities) {
      if (player.getHealth() <= 0.0F && this.popped.containsKey(player.getName())) {
        sendMessage("&3" + player.getName() + " &4died after they popped &6" + this.popped.get(player.getName()) + " totems");
        this.popped.remove(player.getName());
      } 
    } 
  }
  
  public void onDisable() {
    this.popped.clear();
  }
  
  private void sendMessage(String msg) {
    if (this.cName.getValBoolean()) {
      Messages.sendChatMessage(msg);
    } else {
      Messages.sendMessage(msg);
    } 
  }
}
