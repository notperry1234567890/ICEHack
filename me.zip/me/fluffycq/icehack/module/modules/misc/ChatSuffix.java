//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.misc;

import me.fluffycq.icehack.events.PacketEvent;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

public class ChatSuffix extends Module {
  public Setting commands;
  
  String ICEHACK;
  
  @EventHandler
  public Listener<PacketEvent.Send> listener;
  
  public ChatSuffix() {
    super("ChatSuffix", 0, Category.MISC);
    this.ICEHACK = " �?? ɪᴄᴇʜᴀᴄᴋ";
    this.listener = new Listener(event -> {
          if (event.getPacket() instanceof CPacketChatMessage) {
            String s = ((CPacketChatMessage)event.getPacket()).getMessage();
            if (s.startsWith("/") && !this.commands.getValBoolean())
              return; 
            s = s + this.ICEHACK;
            if (s.length() >= 256)
              s = s.substring(0, 256); 
            ((CPacketChatMessage)event.getPacket()).message = s;
          } 
        }new java.util.function.Predicate[0]);
    this.commands = new Setting("OnCommand", this, false);
  }
}
