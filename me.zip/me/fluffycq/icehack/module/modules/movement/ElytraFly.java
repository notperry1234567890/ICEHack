//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.movement;

import java.util.ArrayList;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.events.EventPlayerTravel;
import me.fluffycq.icehack.message.Messages;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.MathUtil;
import me.fluffycq.icehack.util.Timer;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.MathHelper;

public class ElytraFly extends Module {
  public Setting mode;
  
  public Setting speed;
  
  public Setting DownSpeed;
  
  public Setting GlideSpeed;
  
  public Setting UpSpeed;
  
  public Setting Accelerate;
  
  public Setting vAccelerationTimer;
  
  public Setting RotationPitch;
  
  public Setting CancelInWater;
  
  public Setting CancelAtHeight;
  
  public Setting InstantFly;
  
  public Setting EquipElytra;
  
  public Setting debugmsg;
  
  public ArrayList<String> elytraMode = new ArrayList<>();
  
  private Timer PacketTimer = new Timer();
  
  private Timer AccelerationTimer = new Timer();
  
  private Timer AccelerationResetTimer = new Timer();
  
  private Timer InstantFlyTimer = new Timer();
  
  private boolean SendMessage = false;
  
  private int ElytraSlot;
  
  @EventHandler
  private Listener<EventPlayerTravel> OnTravel;
  
  public ElytraFly() {
    super("ElytraFly", 0, Category.MOVEMENT);
    this.ElytraSlot = -1;
    this.OnTravel = new Listener(p_Event -> {
          if (mc.player == null)
            return; 
          this.modInfo = this.mode.getValString().toUpperCase();
          if (this.debugmsg.getValBoolean())
            Messages.sendChatMessage("Current Elytra Mode: " + this.mode.getValString()); 
          if (mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA)
            return; 
          if (ICEHack.fevents.moduleManager.getModule("Freecam").isEnabled())
            return; 
          if (!mc.player.isElytraFlying()) {
            if (!mc.player.onGround && this.InstantFly.getValBoolean()) {
              if (!this.InstantFlyTimer.passed(1000.0D))
                return; 
              this.InstantFlyTimer.reset();
              mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
            } 
            return;
          } 
          if (this.mode.getValString().equalsIgnoreCase("Packet")) {
            if (this.debugmsg.getValBoolean())
              Messages.sendChatMessage("Attempting to fly using mode Packet."); 
            HandleNormalModeElytra(p_Event);
          } else if (this.mode.getValString().equalsIgnoreCase("Superior")) {
            if (this.debugmsg.getValBoolean())
              Messages.sendChatMessage("Attempting to fly using mode Superior."); 
            HandleImmediateModeElytra(p_Event);
          } else if (this.mode.getValString().equalsIgnoreCase("Control")) {
            if (this.debugmsg.getValBoolean())
              Messages.sendChatMessage("Attempting to fly using mode Control."); 
            HandleControlMode(p_Event);
          } 
        }new java.util.function.Predicate[0]);
    this.elytraMode.add("Normal");
    this.elytraMode.add("Tarzan");
    this.elytraMode.add("Superior");
    this.elytraMode.add("Packet");
    this.elytraMode.add("Control");
    this.mode = new Setting("Mode", this, "Superior", this.elytraMode);
    this.speed = new Setting("Speed", this, 1.82D, 0.1D, 5.0D, false);
    this.DownSpeed = new Setting("DownSpeed", this, 1.82D, 0.1D, 5.0D, false);
    this.GlideSpeed = new Setting("GlideSpeed", this, 1.0D, 0.0D, 5.0D, false);
    this.UpSpeed = new Setting("UpSpeed", this, 2.0D, 0.0D, 5.0D, false);
    this.Accelerate = new Setting("Accelerate", this, true);
    this.vAccelerationTimer = new Setting("Timer", this, 1000.0D, 0.0D, 10000.0D, true);
    this.RotationPitch = new Setting("Pitch", this, 0.0D, 0.0D, 90.0D, false);
    this.CancelInWater = new Setting("WaterCancel", this, true);
    this.CancelAtHeight = new Setting("HeightCancel", this, 5.0D, 0.0D, 10.0D, true);
    this.InstantFly = new Setting("InstantFly", this, true);
    this.EquipElytra = new Setting("EquipElytra", this, true);
    this.debugmsg = new Setting("DebugMsgs", this, false);
  }
  
  public void onEnable() {
    this.ElytraSlot = -1;
    if (this.EquipElytra.getValBoolean())
      if (mc.player != null && mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA) {
        for (int l_I = 0; l_I < 44; ) {
          ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);
          if (l_Stack.isEmpty() || l_Stack.getItem() != Items.ELYTRA) {
            l_I++;
            continue;
          } 
          ItemElytra l_Elytra = (ItemElytra)l_Stack.getItem();
          this.ElytraSlot = l_I;
        } 
        if (this.ElytraSlot != -1) {
          boolean l_HasArmorAtChest = (mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.AIR);
          mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.ElytraSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
          mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
          if (l_HasArmorAtChest)
            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.ElytraSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player); 
        } 
      }  
  }
  
  public void onDisable() {
    if (mc.player == null)
      return; 
    if (this.ElytraSlot != -1) {
      boolean l_HasItem = (!mc.player.inventory.getStackInSlot(this.ElytraSlot).isEmpty() || mc.player.inventory.getStackInSlot(this.ElytraSlot).getItem() != Items.AIR);
      mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
      mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.ElytraSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
      if (l_HasItem)
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player); 
    } 
  }
  
  public void HandleNormalModeElytra(EventPlayerTravel p_Travel) {
    double l_YHeight = mc.player.posY;
    if (l_YHeight <= this.CancelAtHeight.getValDouble()) {
      if (!this.SendMessage) {
        Messages.sendChatMessage("&4WARNING, you must scaffold up or use fireworks, as YHeight <= CancelAtHeight!");
        this.SendMessage = true;
      } 
      return;
    } 
    boolean l_IsMoveKeyDown = (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown());
    boolean l_CancelInWater = (!mc.player.isInWater() && !mc.player.isInLava() && this.CancelInWater.getValBoolean());
    if (mc.gameSettings.keyBindJump.isKeyDown()) {
      p_Travel.cancel();
      Accelerate();
      return;
    } 
    if (!l_IsMoveKeyDown) {
      this.AccelerationTimer.resetTimeSkipTo((int)-this.vAccelerationTimer.getValDouble());
    } else if ((mc.player.rotationPitch <= this.RotationPitch.getValDouble() || this.mode.getValString().equalsIgnoreCase("Tarzan")) && l_CancelInWater) {
      if (this.Accelerate.getValBoolean())
        if (this.AccelerationTimer.passed(this.vAccelerationTimer.getValDouble())) {
          Accelerate();
          return;
        }  
      return;
    } 
    p_Travel.cancel();
    Accelerate();
  }
  
  public void HandleImmediateModeElytra(EventPlayerTravel p_Travel) {
    p_Travel.cancel();
    boolean moveForward = mc.gameSettings.keyBindForward.isKeyDown();
    boolean moveBackward = mc.gameSettings.keyBindBack.isKeyDown();
    boolean moveLeft = mc.gameSettings.keyBindLeft.isKeyDown();
    boolean moveRight = mc.gameSettings.keyBindRight.isKeyDown();
    boolean moveUp = mc.gameSettings.keyBindJump.isKeyDown();
    boolean moveDown = mc.gameSettings.keyBindSneak.isKeyDown();
    float moveForwardFactor = moveForward ? 1.0F : (moveBackward ? -1 : false);
    float yawDeg = mc.player.rotationYaw;
    if (moveLeft && (moveForward || moveBackward)) {
      yawDeg -= 40.0F * moveForwardFactor;
    } else if (moveRight && (moveForward || moveBackward)) {
      yawDeg += 40.0F * moveForwardFactor;
    } else if (moveLeft) {
      yawDeg -= 90.0F;
    } else if (moveRight) {
      yawDeg += 90.0F;
    } 
    if (moveBackward)
      yawDeg -= 180.0F; 
    float yaw = (float)Math.toRadians(yawDeg);
    double motionAmount = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
    if (moveUp || moveForward || moveBackward || moveLeft || moveRight) {
      if (moveUp && motionAmount > 1.0D) {
        if (mc.player.motionX == 0.0D && mc.player.motionZ == 0.0D) {
          mc.player.motionY = this.UpSpeed.getValDouble();
        } else {
          double calcMotionDiff = motionAmount * 0.008D;
          mc.player.motionY += calcMotionDiff * 3.2D;
          mc.player.motionX -= -MathHelper.sin(yaw) * calcMotionDiff / 1.0D;
          mc.player.motionZ -= MathHelper.cos(yaw) * calcMotionDiff / 1.0D;
          mc.player.motionX *= 0.9900000095367432D;
          mc.player.motionY *= 0.9800000190734863D;
          mc.player.motionZ *= 0.9900000095367432D;
        } 
      } else {
        mc.player.motionX = -MathHelper.sin(yaw) * 1.7999999523162842D;
        mc.player.motionY = -(this.GlideSpeed.getValDouble() / 10000.0D);
        mc.player.motionZ = MathHelper.cos(yaw) * 1.7999999523162842D;
      } 
    } else {
      mc.player.motionX = 0.0D;
      mc.player.motionY = 0.0D;
      mc.player.motionZ = 0.0D;
    } 
    if (moveDown)
      mc.player.motionY = -this.DownSpeed.getValDouble(); 
    if (moveUp || moveDown);
  }
  
  public void Accelerate() {
    if (this.AccelerationResetTimer.passed(this.vAccelerationTimer.getValDouble())) {
      this.AccelerationResetTimer.reset();
      this.AccelerationTimer.reset();
      this.SendMessage = false;
    } 
    float l_Speed = (float)this.speed.getValDouble();
    double[] dir = MathUtil.directionSpeed(l_Speed);
    mc.player.motionY = -(this.GlideSpeed.getValDouble() / 10000.0D);
    if (mc.player.movementInput.moveStrafe != 0.0F || mc.player.movementInput.moveForward != 0.0F) {
      mc.player.motionX = dir[0];
      mc.player.motionZ = dir[1];
    } else {
      mc.player.motionX = 0.0D;
      mc.player.motionZ = 0.0D;
    } 
    if (mc.gameSettings.keyBindSneak.isKeyDown())
      mc.player.motionY = -this.DownSpeed.getValDouble(); 
    mc.player.prevLimbSwingAmount = 0.0F;
    mc.player.limbSwingAmount = 0.0F;
    mc.player.limbSwing = 0.0F;
  }
  
  private void HandleControlMode(EventPlayerTravel p_Event) {
    double[] dir = MathUtil.directionSpeed(this.speed.getValDouble());
    if (mc.player.movementInput.moveStrafe != 0.0F || mc.player.movementInput.moveForward != 0.0F) {
      mc.player.motionX = dir[0];
      mc.player.motionZ = dir[1];
      mc.player.motionX -= mc.player.motionX * (Math.abs(mc.player.rotationPitch) + 90.0F) / 90.0D - mc.player.motionX;
      mc.player.motionZ -= mc.player.motionZ * (Math.abs(mc.player.rotationPitch) + 90.0F) / 90.0D - mc.player.motionZ;
    } else {
      mc.player.motionX = 0.0D;
      mc.player.motionZ = 0.0D;
    } 
    mc.player.motionY = -MathUtil.degToRad(mc.player.rotationPitch) * mc.player.movementInput.moveForward;
    mc.player.prevLimbSwingAmount = 0.0F;
    mc.player.limbSwingAmount = 0.0F;
    mc.player.limbSwing = 0.0F;
    p_Event.cancel();
  }
}
