//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.movement;

import me.fluffycq.icehack.events.PacketEvent;
import me.fluffycq.icehack.events.PlayerMoveEvent;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.util.MovementInput;
import net.minecraft.world.World;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import org.lwjgl.input.Keyboard;

public class Freecam extends Module {
  Setting speed;
  
  Setting cancelPackets;
  
  private double posX;
  
  private double posY;
  
  private double posZ;
  
  private float pitch;
  
  private float yaw;
  
  private EntityOtherPlayerMP clonedPlayer;
  
  private boolean isRidingEntity;
  
  private Entity ridingEntity;
  
  @EventHandler
  private Listener<PlayerMoveEvent> moveListener;
  
  @EventHandler
  private Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
  
  @EventHandler
  private Listener<PacketEvent.Send> sendListener;
  
  public Freecam() {
    super("Freecam", 0, Category.MOVEMENT);
    this.moveListener = new Listener(event -> mc.player.noClip = true, new java.util.function.Predicate[0]);
    this.pushListener = new Listener(event -> event.setCanceled(true), new java.util.function.Predicate[0]);
    this.sendListener = new Listener(event -> {
          if (this.cancelPackets.getValBoolean() && (event.getPacket() instanceof net.minecraft.network.play.client.CPacketPlayer || event.getPacket() instanceof net.minecraft.network.play.client.CPacketInput))
            event.cancel(); 
        }new java.util.function.Predicate[0]);
    this.speed = new Setting("Speed", this, 1.0D, 0.1D, 5.0D, false);
    this.cancelPackets = new Setting("PacketCancel", this, true);
  }
  
  public void onEnable() {
    if (mc.player != null) {
      this.isRidingEntity = (mc.player.getRidingEntity() != null);
      if (mc.player.getRidingEntity() == null) {
        this.posX = mc.player.posX;
        this.posY = mc.player.posY;
        this.posZ = mc.player.posZ;
      } else {
        this.ridingEntity = mc.player.getRidingEntity();
        mc.player.dismountRidingEntity();
      } 
      this.pitch = mc.player.rotationPitch;
      this.yaw = mc.player.rotationYaw;
      this.clonedPlayer = new EntityOtherPlayerMP((World)mc.world, mc.getSession().getProfile());
      this.clonedPlayer.copyLocationAndAnglesFrom((Entity)mc.player);
      this.clonedPlayer.rotationYawHead = mc.player.rotationYawHead;
      mc.world.addEntityToWorld(-100, (Entity)this.clonedPlayer);
      mc.player.capabilities.isFlying = true;
      mc.player.capabilities.setFlySpeed((float)(this.speed.getValDouble() / 100.0D));
      mc.player.noClip = true;
    } 
  }
  
  public void onDisable() {
    EntityPlayerSP entityPlayerSP = mc.player;
    mc.player.setPositionAndRotation(this.posX, this.posY, this.posZ, this.yaw, this.pitch);
    mc.world.removeEntityFromWorld(-100);
    this.clonedPlayer = null;
    this.posX = this.posY = this.posZ = 0.0D;
    this.pitch = this.yaw = 0.0F;
    mc.player.capabilities.isFlying = false;
    mc.player.capabilities.setFlySpeed(0.05F);
    mc.player.noClip = false;
    mc.player.motionX = mc.player.motionY = mc.player.motionZ = 0.0D;
    if (entityPlayerSP != null && this.isRidingEntity)
      mc.player.startRiding(this.ridingEntity, true); 
  }
  
  public void onUpdate() {
    if (!mc.player.onGround)
      mc.player.motionY = -0.2D; 
    if (Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()))
      mc.player.setPosition(mc.player.posX, mc.player.posY + this.speed.getValDouble(), mc.player.posZ); 
    if (mc.player.isSneaking())
      mc.player.setPosition(mc.player.posX, mc.player.posY - this.speed.getValDouble(), mc.player.posZ); 
    if (Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode()) || Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode())) {
      playersSpeed(this.speed.getValDouble());
    } else {
      mc.player.motionX = 0.0D;
      mc.player.motionZ = 0.0D;
    } 
    mc.player.onGround = true;
    mc.player.motionY = 0.0D;
    mc.player.noClip = true;
    mc.player.onGround = false;
    mc.player.fallDistance = 0.0F;
  }
  
  private void playersSpeed(double speed) {
    if (mc.player != null) {
      MovementInput movementInput = mc.player.movementInput;
      double forward = movementInput.moveForward;
      double strafe = movementInput.moveStrafe;
      float yaw = mc.player.rotationYaw;
      if (forward == 0.0D && strafe == 0.0D) {
        mc.player.motionX = 0.0D;
        mc.player.motionZ = 0.0D;
      } else {
        if (forward != 0.0D) {
          if (strafe > 0.0D) {
            yaw += ((forward > 0.0D) ? -45 : 45);
          } else if (strafe < 0.0D) {
            yaw += ((forward > 0.0D) ? 45 : -45);
          } 
          strafe = 0.0D;
          if (forward > 0.0D) {
            forward = 1.0D;
          } else if (forward < 0.0D) {
            forward = -1.0D;
          } 
        } 
        mc.player
          .motionX = forward * speed * Math.cos(Math.toRadians((yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((yaw + 90.0F)));
        mc.player
          .motionZ = forward * speed * Math.sin(Math.toRadians((yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((yaw + 90.0F)));
      } 
    } 
  }
}
