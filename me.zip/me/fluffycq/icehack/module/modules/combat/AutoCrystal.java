//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.fluffycq.icehack.events.PacketEvent;
import me.fluffycq.icehack.events.RenderEvent;
import me.fluffycq.icehack.friends.Friends;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.ICERenderer;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.potion.Potion;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class AutoCrystal extends Module {
  public Setting place;
  
  public Setting raytrace;
  
  public Setting autoSwitch;
  
  public Setting antiStuck;
  
  public Setting multiPlace;
  
  public Setting onlydamage;
  
  public Setting onlydmgval;
  
  private Setting alert;
  
  private Setting antiSui;
  
  private Setting attackSpeed;
  
  private Setting placeDelay;
  
  private Setting enemyRange;
  
  private Setting minDamage;
  
  private Setting facePlace;
  
  private Setting multiPlaceSpeed;
  
  private Setting placeRange;
  
  private Setting breakRange;
  
  private Setting opacity;
  
  private Setting rendermode;
  
  private Setting width;
  
  ArrayList<String> rendermodes = new ArrayList<>();
  
  private BlockPos render;
  
  public boolean isActive = false;
  
  private Entity renderEnt;
  
  private long placeSystemTime;
  
  private long breakSystemTime;
  
  private long chatSystemTime;
  
  private long multiPlaceSystemTime;
  
  private long antiStuckSystemTime;
  
  public AutoCrystal() {
    super("AutoCrystal", 0, Category.COMBAT);
    this.place = new Setting("Place", this, true);
    this.raytrace = new Setting("RayTrace", this, false);
    this.autoSwitch = new Setting("AutoSwitch", this, true);
    this.antiStuck = new Setting("AntiStuck", this, true);
    this.multiPlace = new Setting("MultiPlace", this, true);
    this.onlydamage = new Setting("OnlyDMG", this, true);
    this.onlydmgval = new Setting("MinBreakDMG", this, 4.0D, 1.0D, 20.0D, true);
    this.alert = new Setting("Msgs", this, true);
    this.antiSui = new Setting("AntiSui", this, true);
    this.attackSpeed = new Setting("BreakSpeed", this, 16.0D, 1.0D, 20.0D, true);
    this.placeDelay = new Setting("PlaceDelay", this, 3.0D, 1.0D, 40.0D, true);
    this.enemyRange = new Setting("Range", this, 8.0D, 1.0D, 13.0D, true);
    this.minDamage = new Setting("MinDmg", this, 6.0D, 1.0D, 16.0D, true);
    this.multiPlaceSpeed = new Setting("MultiSpeed", this, 3.0D, 1.0D, 10.0D, true);
    this.placeRange = new Setting("PlaceRange", this, 6.0D, 1.0D, 6.0D, true);
    this.breakRange = new Setting("BreakRange", this, 6.0D, 1.0D, 6.0D, true);
    this.opacity = new Setting("Opacity", this, 35.0D, 35.0D, 255.0D, true);
    this.rendermodes.add("Full");
    this.rendermodes.add("Up");
    this.rendermodes.add("Outline");
    this.rendermode = new Setting("Mode", this, "Full", this.rendermodes);
    this.width = new Setting("Width", this, 1.0D, 1.0D, 15.0D, false);
    this.placeSystemTime = -1L;
    this.breakSystemTime = -1L;
    this.chatSystemTime = -1L;
    this.multiPlaceSystemTime = -1L;
    this.antiStuckSystemTime = -1L;
    this.switchCooldown = false;
    this.placements = 0;
    Packet[] packet = new Packet[1];
    this.packetListener = new Listener(event -> {
          packet[0] = event.getPacket();
          if (packet[0] instanceof CPacketPlayer && isSpoofingAngles) {
            ((CPacketPlayer)packet[0]).yaw = (float)yaw;
            ((CPacketPlayer)packet[0]).pitch = (float)pitch;
          } 
        }new java.util.function.Predicate[0]);
  }
  
  public void onUpdate() {
    EntityEnderCrystal crystal = mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityEnderCrystal).map(entity -> entity).min(Comparator.comparing(c -> Float.valueOf(mc.player.getDistance(c)))).orElse(null);
    if (crystal != null && mc.player.getDistance((Entity)crystal) <= this.breakRange.getValDouble() && willDamage(crystal)) {
      if ((System.nanoTime() / 1000000L - this.breakSystemTime) >= 420.0D - this.attackSpeed.getValDouble() * 20.0D) {
        lookAtPacket(crystal.posX, crystal.posY, crystal.posZ, (EntityPlayer)mc.player);
        mc.playerController.attackEntity((EntityPlayer)mc.player, (Entity)crystal);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        this.breakSystemTime = System.nanoTime() / 1000000L;
      } 
      if (this.multiPlace.getValBoolean()) {
        if ((System.nanoTime() / 1000000L - this.multiPlaceSystemTime) >= 20.0D * this.multiPlaceSpeed.getValDouble() && (System.nanoTime() / 1000000L - this.antiStuckSystemTime) <= 400.0D + 400.0D - this.attackSpeed.getValDouble() * 20.0D) {
          this.multiPlaceSystemTime = System.nanoTime() / 1000000L;
          return;
        } 
      } else if ((System.nanoTime() / 1000000L - this.antiStuckSystemTime) <= 400.0D + 400.0D - this.attackSpeed.getValDouble() * 20.0D) {
        return;
      } 
    } else {
      resetRotation();
    } 
    int crystalSlot = (mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) ? mc.player.inventory.currentItem : -1;
    if (crystalSlot == -1)
      for (int l = 0; l < 9; l++) {
        if (mc.player.inventory.getStackInSlot(l).getItem() == Items.END_CRYSTAL) {
          crystalSlot = l;
          break;
        } 
      }  
    boolean offhand = false;
    if (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
      offhand = true;
    } else if (crystalSlot == -1) {
      return;
    } 
    Entity ent = null;
    Entity lastTarget = null;
    BlockPos finalPos = null;
    List<BlockPos> blocks = findCrystalBlocks();
    List<Entity> entities = new ArrayList<>();
    entities.addAll((Collection<? extends Entity>)mc.world.playerEntities.stream().filter(entityPlayer -> !Friends.isFriend(entityPlayer.getName())).collect(Collectors.toList()));
    double damage = 0.5D;
    for (Entity entity2 : entities) {
      if (entity2 == mc.player || (
        (EntityLivingBase)entity2).getHealth() <= 0.0F)
        continue; 
      if (mc.player.getDistanceSq(entity2) > this.enemyRange.getValDouble() * this.enemyRange.getValDouble())
        continue; 
      for (BlockPos blockPos : blocks) {
        if (!canBlockBeSeen(blockPos) && mc.player.getDistanceSq(blockPos) > 25.0D && this.raytrace.getValBoolean())
          continue; 
        double b = entity2.getDistanceSq(blockPos);
        if (b > 56.2D)
          continue; 
        double d = calculateDamage(blockPos.x + 0.5D, (blockPos.y + 1), blockPos.z + 0.5D, entity2);
        if (d < this.minDamage.getValDouble() && (((EntityLivingBase)entity2).getHealth() + ((EntityLivingBase)entity2).getAbsorptionAmount()) > 8.0D)
          continue; 
        if (d <= damage)
          continue; 
        double self = calculateDamage(blockPos.x + 0.5D, (blockPos.y + 1), blockPos.z + 0.5D, (Entity)mc.player);
        if (this.antiSui.getValBoolean()) {
          if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) - self <= 7.0D)
            continue; 
          if (self > d)
            continue; 
        } 
        this.target = entity2;
        damage = d;
        finalPos = blockPos;
        ent = entity2;
        lastTarget = entity2;
      } 
    } 
    if (damage == 0.5D) {
      this.render = null;
      this.renderEnt = null;
      resetRotation();
      return;
    } 
    this.render = finalPos;
    this.renderEnt = ent;
    if (this.place.getValBoolean()) {
      EnumFacing f;
      if (!offhand && mc.player.inventory.currentItem != crystalSlot) {
        if (this.autoSwitch.getValBoolean()) {
          mc.player.inventory.currentItem = crystalSlot;
          resetRotation();
          this.switchCooldown = true;
        } 
        return;
      } 
      lookAtPacket(finalPos.x + 0.5D, finalPos.y - 0.5D, finalPos.z + 0.5D, (EntityPlayer)mc.player);
      RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(finalPos.x + 0.5D, finalPos.y - 0.5D, finalPos.z + 0.5D));
      if (result == null || result.sideHit == null) {
        f = EnumFacing.UP;
      } else {
        f = result.sideHit;
      } 
      if (this.switchCooldown) {
        this.switchCooldown = false;
        return;
      } 
      if ((System.nanoTime() / 1000000L - this.placeSystemTime) >= this.placeDelay.getValDouble() * 2.0D) {
        mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(finalPos, f, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
        this.placements++;
        this.antiStuckSystemTime = System.nanoTime() / 1000000L;
        this.placeSystemTime = System.nanoTime() / 1000000L;
      } 
    } 
    if (isSpoofingAngles)
      if (togglePitch) {
        EntityPlayerSP player = mc.player;
        player.rotationPitch += 4.0E-4F;
        togglePitch = false;
      } else {
        EntityPlayerSP player2 = mc.player;
        player2.rotationPitch -= 4.0E-4F;
        togglePitch = true;
      }  
  }
  
  public void onWorld(RenderEvent event) {
    if (this.render != null) {
      float[] hue = { (float)(System.currentTimeMillis() % 11520L) / 11520.0F };
      int rgb = Color.HSBtoRGB(hue[0], 1.0F, 1.0F);
      int r = rgb >> 16 & 0xFF;
      int g = rgb >> 8 & 0xFF;
      int b = rgb & 0xFF;
      if (this.rendermode.getValString().equalsIgnoreCase("Up")) {
        ICERenderer.prepare(7);
        ICERenderer.drawBoxOpacity(this.render, rgb, (int)this.opacity.getValDouble(), 2);
        ICERenderer.release();
      } else if (this.rendermode.getValString().equalsIgnoreCase("Full")) {
        ICERenderer.prepare(7);
        ICERenderer.drawBox(this.render, r, g, b, 77, 63);
        ICERenderer.release();
        ICERenderer.prepare(7);
        ICERenderer.drawBoundingBoxBlockPos(this.render, 1.0F, r, g, b, (int)this.opacity.getValDouble());
        ICERenderer.release();
      } else if (this.rendermode.getValString().equalsIgnoreCase("Outline")) {
        ICERenderer.prepare(7);
        ICERenderer.drawBoundingBoxBlockPos(this.render, (float)this.width.getValDouble(), r, g, b, (int)this.opacity.getValDouble());
        ICERenderer.release();
      } 
    } 
  }
  
  private void lookAtPacket(double px, double py, double pz, EntityPlayer me) {
    double[] v = calculateLookAt(px, py, pz, me);
    setYawAndPitch((float)v[0], (float)v[1]);
  }
  
  private boolean canPlaceCrystal(BlockPos blockPos) {
    BlockPos boost = blockPos.add(0, 1, 0);
    BlockPos boost2 = blockPos.add(0, 2, 0);
    return ((mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && mc.world.getBlockState(boost).getBlock() == Blocks.AIR && mc.world.getBlockState(boost2).getBlock() == Blocks.AIR && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
  }
  
  public static BlockPos getPlayerPos() {
    return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
  }
  
  private List<BlockPos> findCrystalBlocks() {
    NonNullList positions = NonNullList.create();
    this;
    positions.addAll((Collection)getSphere(getPlayerPos(), (float)this.placeRange.getValDouble(), (int)this.placeRange.getValDouble(), false, true, 0).stream().filter(this::canPlaceCrystal).collect(Collectors.toList()));
    return (List<BlockPos>)positions;
  }
  
  public boolean willDamage(EntityEnderCrystal crystal) {
    boolean willDamage = false;
    if (this.onlydamage.getValBoolean()) {
      List<Entity> entities = new ArrayList<>();
      entities.addAll((Collection<? extends Entity>)mc.world.playerEntities.stream().filter(entityPlayer -> !Friends.isFriend(entityPlayer.getName())).collect(Collectors.toList()));
      for (Entity e : entities) {
        if (e == mc.player || 
          !(e instanceof EntityLivingBase))
          continue; 
        if (((EntityLivingBase)e).getHealth() <= 0.0F)
          continue; 
        if (mc.player.getDistanceSq(e) > this.enemyRange.getValDouble() * this.enemyRange.getValDouble())
          continue; 
        if (calculateDamage(crystal.posX, crystal.posY, crystal.posZ, e) >= this.onlydmgval.getValDouble() && !willDamage) {
          willDamage = true;
          break;
        } 
      } 
    } else {
      willDamage = true;
    } 
    return willDamage;
  }
  
  public static List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
    List<BlockPos> circleblocks = new ArrayList<>();
    int cx = loc.getX();
    int cy = loc.getY();
    int cz = loc.getZ();
    for (int x = cx - (int)r; x <= cx + r; x++) {
      for (int z = cz - (int)r; z <= cz + r; ) {
        int y = sphere ? (cy - (int)r) : cy;
        for (;; z++) {
          if (y < (sphere ? (cy + r) : (cy + h))) {
            double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
            if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
              BlockPos l = new BlockPos(x, y + plus_y, z);
              circleblocks.add(l);
            } 
            y++;
            continue;
          } 
        } 
      } 
    } 
    return circleblocks;
  }
  
  public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
    float doubleExplosionSize = 12.0F;
    double distancedsize = entity.getDistance(posX, posY, posZ) / 12.0D;
    Vec3d vec3d = new Vec3d(posX, posY, posZ);
    double blockDensity = entity.world.getBlockDensity(vec3d, entity.getEntityBoundingBox());
    double v = (1.0D - distancedsize) * blockDensity;
    float damage = (int)((v * v + v) / 2.0D * 7.0D * 12.0D + 1.0D);
    double finald = 1.0D;
    if (entity instanceof EntityLivingBase)
      finald = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion((World)mc.world, (Entity)null, posX, posY, posZ, 6.0F, false, true)); 
    return (float)finald;
  }
  
  public static float getBlastReduction(EntityLivingBase entity, float damage, Explosion explosion) {
    if (entity instanceof EntityPlayer) {
      EntityPlayer ep = (EntityPlayer)entity;
      DamageSource ds = DamageSource.causeExplosionDamage(explosion);
      damage = CombatRules.getDamageAfterAbsorb(damage, ep.getTotalArmorValue(), (float)ep.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
      int k = EnchantmentHelper.getEnchantmentModifierDamage(ep.getArmorInventoryList(), ds);
      float f = MathHelper.clamp(k, 0.0F, 20.0F);
      damage *= 1.0F - f / 25.0F;
      if (entity.isPotionActive(Potion.getPotionById(11)))
        damage -= damage / 4.0F; 
      return damage;
    } 
    damage = CombatRules.getDamageAfterAbsorb(damage, entity.getTotalArmorValue(), (float)entity.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
    return damage;
  }
  
  private static float getDamageMultiplied(float damage) {
    int diff = mc.world.getDifficulty().getId();
    return damage * ((diff == 0) ? 0.0F : ((diff == 2) ? 1.0F : ((diff == 1) ? 0.5F : 1.5F)));
  }
  
  public static float calculateDamage(EntityEnderCrystal crystal, Entity entity) {
    return calculateDamage(crystal.posX, crystal.posY, crystal.posZ, entity);
  }
  
  public static boolean canBlockBeSeen(BlockPos blockPos) {
    return (mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(blockPos.getX(), blockPos.getY(), blockPos.getZ()), false, true, false) == null);
  }
  
  private static void setYawAndPitch(float yaw1, float pitch1) {
    yaw = yaw1;
    pitch = pitch1;
    isSpoofingAngles = true;
  }
  
  private static void resetRotation() {
    if (isSpoofingAngles) {
      yaw = mc.player.rotationYaw;
      pitch = mc.player.rotationPitch;
      isSpoofingAngles = false;
    } 
  }
  
  public void onDisable() {
    this.render = null;
    resetRotation();
  }
  
  private static boolean togglePitch = false;
  
  private boolean switchCooldown;
  
  private int newSlot;
  
  private int placements;
  
  private static boolean isSpoofingAngles;
  
  private static double yaw;
  
  private static double pitch;
  
  private Entity target;
  
  @EventHandler
  private Listener<PacketEvent.Send> packetListener;
  
  public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer me) {
    double dirx = me.posX - px;
    double diry = me.posY - py;
    double dirz = me.posZ - pz;
    double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
    dirx /= len;
    diry /= len;
    dirz /= len;
    double pitch = Math.asin(diry);
    double yaw = Math.atan2(dirz, dirx);
    pitch = pitch * 180.0D / Math.PI;
    yaw = yaw * 180.0D / Math.PI;
    yaw += 90.0D;
    return new double[] { yaw, pitch };
  }
}
