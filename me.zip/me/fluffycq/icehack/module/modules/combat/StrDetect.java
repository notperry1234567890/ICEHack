//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import java.util.ArrayList;
import me.fluffycq.icehack.message.Messages;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;

public class StrDetect extends Module {
  ArrayList<String> users;
  
  public StrDetect() {
    super("StrDetect", 0, Category.COMBAT);
    this.users = new ArrayList<>();
  }
  
  public void onEnable() {
    this.users.clear();
  }
  
  public void onUpdate() {
    for (Entity e : mc.world.loadedEntityList) {
      if (!(e instanceof EntityLivingBase))
        continue; 
      if (e == mc.player)
        continue; 
      if (((EntityLivingBase)e).getHealth() <= 0.0F)
        continue; 
      if (e instanceof EntityPlayer) {
        EntityPlayer p = (EntityPlayer)e;
        if (p.getActivePotionMap() != null) {
          if (p.isPotionActive(MobEffects.STRENGTH) && !this.users.contains(p.getName())) {
            this.users.add(p.getName());
            Messages.sendChatMessage("&3" + p.getName() + " &anow has Strength.");
          } 
          if (!p.isPotionActive(MobEffects.STRENGTH) && this.users.contains(p.getName())) {
            this.users.remove(p.getName());
            Messages.sendChatMessage("&3" + p.getName() + " &4no longer has Strength.");
          } 
        } 
      } 
    } 
  }
  
  public void onDisable() {
    this.users.clear();
  }
}
