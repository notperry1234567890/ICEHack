//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import java.util.ArrayList;
import me.fluffycq.icehack.message.Messages;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.InventoryUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class AutoTotem extends Module {
  Setting priority;
  
  public ArrayList<String> priorities = new ArrayList<>();
  
  Setting health;
  
  Setting messages;
  
  Setting smart;
  
  Setting smartdelay;
  
  Setting allowGap;
  
  Setting debug;
  
  int totems;
  
  int smartTick;
  
  boolean isSmart;
  
  public AutoTotem() {
    super("AutoTotem", 0, Category.COMBAT);
    this.totems = 0;
    this.health = new Setting("Health", this, 11.0D, 5.0D, 36.0D, false);
    this.priorities.add("Totem");
    this.priorities.add("Crystal");
    this.priorities.add("Gapple");
    this.priority = new Setting("Priority", this, "Totem", this.priorities);
    this.allowGap = new Setting("AllowGap", this, true);
    this.messages = new Setting("Alerts", this, false);
    this.debug = new Setting("Debug", this, false);
  }
  
  public void switchOffhand(String item) {
    Item prioItem = null;
    switch (item) {
      case "Totem":
        prioItem = Items.TOTEM_OF_UNDYING;
        break;
      case "Crystal":
        prioItem = Items.END_CRYSTAL;
        break;
      case "Gapple":
        prioItem = Items.GOLDEN_APPLE;
        break;
    } 
    int slot = InventoryUtil.getItem(prioItem);
    if (slot != -1) {
      if (this.messages.getValBoolean())
        Messages.sendChatMessage("AutoTotem equipped you with a " + item); 
      mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
      mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
      mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
      mc.playerController.updateController();
    } else {
      int tslot = InventoryUtil.getItem(Items.TOTEM_OF_UNDYING);
      if (tslot != -1) {
        if (this.messages.getValBoolean())
          Messages.sendChatMessage("Fallback Emergency Totem equipped!"); 
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, tslot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, tslot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
        mc.playerController.updateController();
      } 
    } 
  }
  
  public void onEnable() {
    this.smartTick = 0;
    this.isSmart = false;
  }
  
  public void onUpdate() {
    if (mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory))
      return; 
    this.totems = mc.player.inventory.mainInventory.stream().filter(itemStack -> (itemStack.getItem() == Items.TOTEM_OF_UNDYING)).mapToInt(ItemStack::getCount).sum();
    if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING)
      this.totems++; 
    this.modInfo = (String.valueOf(this.totems) != null) ? String.valueOf(this.totems) : "0";
    if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) >= this.health.getValDouble() && !mc.player.getHeldItemOffhand().getItem().equals(getItemVal(this.priority.getValString())))
      if (this.allowGap.getValBoolean()) {
        if (!mc.player.getHeldItemOffhand().getItem().equals(Items.GOLDEN_APPLE))
          switchOffhand(this.priority.getValString()); 
      } else {
        switchOffhand(this.priority.getValString());
      }  
    if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) <= this.health.getValDouble() && !mc.player.getHeldItemOffhand().getItem().equals(Items.TOTEM_OF_UNDYING))
      switchOffhand("Totem"); 
  }
  
  public void onDisable() {
    this.smartTick = 0;
    this.isSmart = false;
  }
  
  public Item getItemVal(String i) {
    Item prioItem = null;
    switch (i) {
      case "Totem":
        prioItem = Items.TOTEM_OF_UNDYING;
        break;
      case "Crystal":
        prioItem = Items.END_CRYSTAL;
        break;
      case "Gapple":
        prioItem = Items.GOLDEN_APPLE;
        break;
    } 
    return prioItem;
  }
  
  public boolean crystalsWillKill() {
    boolean willKill = false;
    for (Entity e : mc.world.loadedEntityList) {
      if (!(e instanceof EntityEnderCrystal))
        continue; 
      EntityEnderCrystal crystal = (EntityEnderCrystal)e;
      if (crystal != null)
        if (AutoCrystal.calculateDamage(crystal.posX + 0.5D, crystal.posY + 1.0D, crystal.posZ + 0.5D, (Entity)mc.player) >= mc.player.getHealth() + mc.player.getAbsorptionAmount() && !willKill)
          willKill = true;  
    } 
    return willKill;
  }
  
  public double getCrystalDMG() {
    boolean willKill = false;
    double dmg = 0.0D;
    for (Entity e : mc.world.loadedEntityList) {
      if (!(e instanceof EntityEnderCrystal))
        continue; 
      EntityEnderCrystal crystal = (EntityEnderCrystal)e;
      if (crystal != null) {
        dmg = AutoCrystal.calculateDamage(crystal.posX + 0.5D, crystal.posY + 1.0D, crystal.posZ + 0.5D, (Entity)mc.player);
        if (AutoCrystal.calculateDamage(crystal.posX + 0.5D, crystal.posY + 1.0D, crystal.posZ + 0.5D, (Entity)mc.player) >= mc.player.getHealth() + mc.player.getAbsorptionAmount() && !willKill)
          willKill = true; 
      } 
    } 
    return dmg;
  }
}
