//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.fluffycq.icehack.friends.Friends;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.BlockUtil;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class AutoTrap extends Module {
  public Setting blocksper;
  
  public Setting delay;
  
  public Setting range;
  
  private EntityPlayer closestTarget;
  
  private String lastTickTargetName;
  
  private int playerHotbarSlot;
  
  private int lastHotbarSlot;
  
  private int delayStep;
  
  private boolean isSneaking;
  
  private int offsetStep;
  
  private boolean firstRun;
  
  public AutoTrap() {
    super("AutoTrap", 0, Category.COMBAT);
    this.playerHotbarSlot = -1;
    this.lastHotbarSlot = -1;
    this.delayStep = 0;
    this.isSneaking = false;
    this.offsetStep = 0;
    this.delay = new Setting("Delay", this, 2.0D, 1.0D, 16.0D, true);
    this.blocksper = new Setting("BPT", this, 3.0D, 1.0D, 6.0D, true);
    this.range = new Setting("Range", this, 3.0D, 1.0D, 5.0D, true);
  }
  
  public void onEnable() {
    if (mc.player == null) {
      disable();
      return;
    } 
    this.firstRun = true;
    this.playerHotbarSlot = mc.player.inventory.currentItem;
    this.lastHotbarSlot = -1;
  }
  
  public void onDisable() {
    if (mc.player == null)
      return; 
    if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1)
      mc.player.inventory.currentItem = this.playerHotbarSlot; 
    if (this.isSneaking) {
      mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
      this.isSneaking = false;
    } 
    this.playerHotbarSlot = -1;
    this.lastHotbarSlot = -1;
  }
  
  public void onUpdate() {
    if (mc.player == null)
      return; 
    if (!this.firstRun) {
      if (this.delayStep < this.delay.getValDouble()) {
        this.delayStep++;
        return;
      } 
      this.delayStep = 0;
    } 
    findClosestTarget();
    if (this.closestTarget == null) {
      if (this.firstRun)
        this.firstRun = false; 
      return;
    } 
    if (this.firstRun) {
      this.firstRun = false;
      this.lastTickTargetName = this.closestTarget.getName();
    } else if (!this.lastTickTargetName.equals(this.closestTarget.getName())) {
      this.lastTickTargetName = this.closestTarget.getName();
      this.offsetStep = 0;
    } 
    List<Vec3d> placeTargets = new ArrayList<>();
    Collections.addAll(placeTargets, BlockUtil.TRAP);
    int blocksPlaced = 0;
    while (blocksPlaced < this.blocksper.getValDouble()) {
      if (this.offsetStep >= placeTargets.size()) {
        this.offsetStep = 0;
        break;
      } 
      BlockPos offsetPos = new BlockPos(placeTargets.get(this.offsetStep));
      BlockPos targetPos = (new BlockPos(this.closestTarget.getPositionVector())).down().add(offsetPos.x, offsetPos.y, offsetPos.z);
      if (placeBlockInRange(targetPos, this.range.getValDouble()))
        blocksPlaced++; 
      this.offsetStep++;
    } 
    if (blocksPlaced > 0) {
      if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
        mc.player.inventory.currentItem = this.playerHotbarSlot;
        this.lastHotbarSlot = this.playerHotbarSlot;
      } 
      if (this.isSneaking) {
        mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        this.isSneaking = false;
      } 
    } 
    this.modInfo = (this.closestTarget != null) ? this.closestTarget.getName() : "None";
  }
  
  private boolean placeBlockInRange(BlockPos pos, double range) {
    Block block = mc.world.getBlockState(pos).getBlock();
    if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid))
      return false; 
    for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos))) {
      if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb))
        return false; 
    } 
    EnumFacing side = BlockUtil.getPlaceableSide(pos);
    if (side == null)
      return false; 
    BlockPos neighbour = pos.offset(side);
    EnumFacing opposite = side.getOpposite();
    if (!BlockUtil.canBeClicked(neighbour))
      return false; 
    Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
    Block neighbourBlock = mc.world.getBlockState(neighbour).getBlock();
    if (mc.player.getPositionVector().distanceTo(hitVec) > range)
      return false; 
    int obiSlot = findObiInHotbar();
    if (obiSlot == -1)
      disable(); 
    if (this.lastHotbarSlot != obiSlot) {
      mc.player.inventory.currentItem = obiSlot;
      this.lastHotbarSlot = obiSlot;
    } 
    if ((!this.isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
      mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
      this.isSneaking = true;
    } 
    BlockUtil.faceVectorPacketInstant(hitVec);
    mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, opposite, hitVec, EnumHand.MAIN_HAND);
    mc.player.swingArm(EnumHand.MAIN_HAND);
    mc.rightClickDelayTimer = 4;
    return true;
  }
  
  private int findObiInHotbar() {
    int slot = -1;
    for (int i = 0; i < 9; i++) {
      ItemStack stack = mc.player.inventory.getStackInSlot(i);
      if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
        Block block = ((ItemBlock)stack.getItem()).getBlock();
        if (block instanceof net.minecraft.block.BlockObsidian) {
          slot = i;
          break;
        } 
      } 
    } 
    return slot;
  }
  
  private void findClosestTarget() {
    List<EntityPlayer> playerList = mc.world.playerEntities;
    this.closestTarget = null;
    for (EntityPlayer target : playerList) {
      if (target == mc.player)
        continue; 
      if (Friends.isFriend(target.getName()))
        continue; 
      if (!(target instanceof net.minecraft.entity.EntityLivingBase))
        continue; 
      if (target.getHealth() <= 0.0F)
        continue; 
      if (this.closestTarget == null) {
        this.closestTarget = target;
        continue;
      } 
      if (mc.player.getDistance((Entity)target) < mc.player.getDistance((Entity)this.closestTarget))
        this.closestTarget = target; 
    } 
  }
}
