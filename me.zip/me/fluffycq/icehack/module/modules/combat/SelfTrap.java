//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import me.fluffycq.icehack.friends.Friends;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.util.BlockUtil;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class SelfTrap extends Module {
  public Setting blocksper;
  
  public Setting delay;
  
  public Setting smart;
  
  public Setting range;
  
  public Setting autocenter;
  
  private int playerHotbarSlot;
  
  private int lastHotbarSlot;
  
  private int delayStep;
  
  private boolean isSneaking;
  
  private int offsetStep;
  
  private boolean firstRun;
  
  private EntityPlayer closestTarget;
  
  public SelfTrap() {
    super("SelfTrap", 0, Category.COMBAT);
    this.playerHotbarSlot = -1;
    this.lastHotbarSlot = -1;
    this.delayStep = 0;
    this.isSneaking = false;
    this.offsetStep = 0;
    this.delay = new Setting("Delay", this, 2.0D, 1.0D, 16.0D, true);
    this.blocksper = new Setting("BPT", this, 3.0D, 1.0D, 6.0D, true);
    this.autocenter = new Setting("AutoCenter", this, true);
    this.smart = new Setting("Smart", this, true);
    this.range = new Setting("Range", this, 3.0D, 1.0D, 5.0D, true);
  }
  
  public void onEnable() {
    if (mc.player == null) {
      disable();
      return;
    } 
    double y = mc.player.getPosition().getY();
    double x = mc.player.getPosition().getX();
    double z = mc.player.getPosition().getZ();
    Vec3d plusPlus = new Vec3d(x + 0.5D, y, z + 0.5D);
    Vec3d plusMinus = new Vec3d(x + 0.5D, y, z - 0.5D);
    Vec3d minusMinus = new Vec3d(x - 0.5D, y, z - 0.5D);
    Vec3d minusPlus = new Vec3d(x - 0.5D, y, z + 0.5D);
    if (this.autocenter.getValBoolean()) {
      if (getDst(plusPlus) < getDst(plusMinus) && getDst(plusPlus) < getDst(minusMinus) && getDst(plusPlus) < getDst(minusPlus)) {
        x = mc.player.getPosition().getX() + 0.5D;
        z = mc.player.getPosition().getZ() + 0.5D;
        centerPlayer(x, y, z);
      } 
      if (getDst(plusMinus) < getDst(plusPlus) && getDst(plusMinus) < getDst(minusMinus) && getDst(plusMinus) < getDst(minusPlus)) {
        x = mc.player.getPosition().getX() + 0.5D;
        z = mc.player.getPosition().getZ() - 0.5D;
        centerPlayer(x, y, z);
      } 
      if (getDst(minusMinus) < getDst(plusPlus) && getDst(minusMinus) < getDst(plusMinus) && getDst(minusMinus) < getDst(minusPlus)) {
        x = mc.player.getPosition().getX() - 0.5D;
        z = mc.player.getPosition().getZ() - 0.5D;
        centerPlayer(x, y, z);
      } 
      if (getDst(minusPlus) < getDst(plusPlus) && getDst(minusPlus) < getDst(plusMinus) && getDst(minusPlus) < getDst(minusMinus)) {
        x = mc.player.getPosition().getX() - 0.5D;
        z = mc.player.getPosition().getZ() + 0.5D;
        centerPlayer(x, y, z);
      } 
    } 
    this.firstRun = true;
    this.playerHotbarSlot = mc.player.inventory.currentItem;
    this.lastHotbarSlot = -1;
  }
  
  public void onDisable() {
    this.closestTarget = null;
    if (mc.player == null)
      return; 
    if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1)
      mc.player.inventory.currentItem = this.playerHotbarSlot; 
    if (this.isSneaking) {
      mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
      this.isSneaking = false;
    } 
    this.playerHotbarSlot = -1;
    this.lastHotbarSlot = -1;
  }
  
  public void onUpdate() {
    if (this.smart.getValBoolean())
      findClosestTarget(); 
    if (mc.player == null)
      return; 
    if (!this.firstRun) {
      if (this.delayStep < (int)this.delay.getValDouble()) {
        this.delayStep++;
        return;
      } 
      this.delayStep = 0;
    } 
    List<Vec3d> placeTargets = new ArrayList<>();
    if (!this.smart.getValBoolean()) {
      Collections.addAll(placeTargets, BlockUtil.TRAP);
    } else if (getViewYaw() <= 315 && getViewYaw() >= 225) {
      Collections.addAll(placeTargets, BlockUtil.BLOCKOVERHEADFACINGNEGX);
    } else if ((getViewYaw() < 45 && getViewYaw() > 0) || (getViewYaw() > 315 && getViewYaw() < 360)) {
      Collections.addAll(placeTargets, BlockUtil.BLOCKOVERHEADFACINGPOSZ);
    } else if (getViewYaw() <= 135 && getViewYaw() >= 45) {
      Collections.addAll(placeTargets, BlockUtil.BLOCKOVERHEADFACINGPOSX);
    } else if (getViewYaw() < 225 && getViewYaw() > 135) {
      Collections.addAll(placeTargets, BlockUtil.BLOCKOVERHEADFACINGNEGZ);
    } 
    int blocksPlaced = 0;
    while (blocksPlaced < (int)this.blocksper.getValDouble()) {
      if (this.offsetStep >= placeTargets.size()) {
        this.offsetStep = 0;
        break;
      } 
      BlockPos offsetPos = new BlockPos(placeTargets.get(this.offsetStep));
      BlockPos targetPos = (new BlockPos(mc.player.getPositionVector())).down().add(offsetPos.x, offsetPos.y, offsetPos.z);
      if (this.closestTarget != null && this.smart.getValBoolean()) {
        if (isInRange(getClosestTargetPos()) && 
          placeBlockInRange(targetPos))
          blocksPlaced++; 
      } else if (!this.smart.getValBoolean() && 
        placeBlockInRange(targetPos)) {
        blocksPlaced++;
      } 
      this.offsetStep++;
    } 
    if (blocksPlaced > 0) {
      if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
        mc.player.inventory.currentItem = this.playerHotbarSlot;
        this.lastHotbarSlot = this.playerHotbarSlot;
      } 
      if (this.isSneaking) {
        mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        this.isSneaking = false;
      } 
    } 
    Vec3d overHead = new Vec3d(0.0D, 3.0D, 0.0D);
    BlockPos blockOverHead = (new BlockPos(mc.player.getPositionVector())).down().add(overHead.x, overHead.y, overHead.z);
    Block block2 = mc.world.getBlockState(blockOverHead).getBlock();
  }
  
  private boolean placeBlockInRange(BlockPos pos) {
    Block block = mc.world.getBlockState(pos).getBlock();
    if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid))
      return false; 
    for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos))) {
      if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb))
        return false; 
    } 
    EnumFacing side = BlockUtil.getPlaceableSide(pos);
    if (side == null)
      return false; 
    BlockPos neighbour = pos.offset(side);
    EnumFacing opposite = side.getOpposite();
    if (!BlockUtil.canBeClicked(neighbour))
      return false; 
    Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
    Block neighbourBlock = mc.world.getBlockState(neighbour).getBlock();
    int obiSlot = findObiInHotbar();
    if (obiSlot == -1)
      disable(); 
    if (this.lastHotbarSlot != obiSlot) {
      mc.player.inventory.currentItem = obiSlot;
      this.lastHotbarSlot = obiSlot;
    } 
    if ((!this.isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
      mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
      this.isSneaking = true;
    } 
    BlockUtil.faceVectorPacketInstant(hitVec);
    mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, opposite, hitVec, EnumHand.MAIN_HAND);
    mc.player.swingArm(EnumHand.MAIN_HAND);
    mc.rightClickDelayTimer = 0;
    return true;
  }
  
  public static BlockPos getPlayerPos() {
    return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
  }
  
  public BlockPos getClosestTargetPos() {
    if (this.closestTarget != null)
      return new BlockPos(Math.floor(this.closestTarget.posX), Math.floor(this.closestTarget.posY), Math.floor(this.closestTarget.posZ)); 
    return null;
  }
  
  public int getViewYaw() {
    return (int)Math.abs(Math.floor(((Minecraft.getMinecraft()).player.rotationYaw * 8.0F / 360.0F)));
  }
  
  private void findClosestTarget() {
    List<EntityPlayer> playerList = mc.world.playerEntities;
    this.closestTarget = null;
    for (EntityPlayer target : playerList) {
      if (target == mc.player)
        continue; 
      if (Friends.isFriend(target.getName()))
        continue; 
      if (!(target instanceof net.minecraft.entity.EntityLivingBase))
        continue; 
      if (target.getHealth() <= 0.0F)
        continue; 
      if (this.closestTarget == null) {
        this.closestTarget = target;
        continue;
      } 
      if (mc.player.getDistance((Entity)target) < mc.player.getDistance((Entity)this.closestTarget))
        this.closestTarget = target; 
    } 
  }
  
  private boolean isInRange(BlockPos blockPos) {
    NonNullList<BlockPos> positions = NonNullList.create();
    positions.addAll((Collection)
        getSphere(getPlayerPos(), (float)this.range.getValDouble(), (int)this.range.getValDouble(), false, true, 0)
        .stream().collect(Collectors.toList()));
    if (positions.contains(blockPos))
      return true; 
    return false;
  }
  
  public List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
    List<BlockPos> circleblocks = new ArrayList<>();
    int cx = loc.getX();
    int cy = loc.getY();
    int cz = loc.getZ();
    for (int x = cx - (int)r; x <= cx + r; x++) {
      for (int z = cz - (int)r; z <= cz + r; ) {
        int y = sphere ? (cy - (int)r) : cy;
        for (;; z++) {
          if (y < (sphere ? (cy + r) : (cy + h))) {
            double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
            if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
              BlockPos l = new BlockPos(x, y + plus_y, z);
              circleblocks.add(l);
            } 
            y++;
            continue;
          } 
        } 
      } 
    } 
    return circleblocks;
  }
  
  private int findObiInHotbar() {
    int slot = -1;
    for (int i = 0; i < 9; i++) {
      ItemStack stack = mc.player.inventory.getStackInSlot(i);
      if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
        Block block = ((ItemBlock)stack.getItem()).getBlock();
        if (block instanceof net.minecraft.block.BlockObsidian) {
          slot = i;
          break;
        } 
      } 
    } 
    return slot;
  }
  
  private void centerPlayer(double x, double y, double z) {
    mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y, z, true));
    mc.player.setPosition(x, y, z);
  }
  
  private double getDst(Vec3d vec) {
    return mc.player.getPositionVector().distanceTo(vec);
  }
}
