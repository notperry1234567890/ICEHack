//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.module.modules.combat;

import me.fluffycq.icehack.friends.Friends;
import me.fluffycq.icehack.module.Category;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.setting.Setting;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumHand;

public class TickAura extends Module {
  public Setting ttkswitch;
  
  public Setting range;
  
  public Setting delay;
  
  public Setting onlyttk;
  
  boolean foundsword;
  
  int Dticks;
  
  public TickAura() {
    super("TickAura", 0, Category.COMBAT);
    this.foundsword = false;
    this.ttkswitch = new Setting("32kSwitch", this, true);
    this.range = new Setting("Range", this, 4.5D, 1.0D, 7.0D, false);
    this.delay = new Setting("TickDelay", this, 3.0D, 1.0D, 60.0D, true);
    this.onlyttk = new Setting("Only32k", this, true);
  }
  
  public void onUpdate() {
    if (mc.player.isDead || mc.world == null)
      return; 
    this.Dticks++;
    if (this.ttkswitch.getValBoolean()) {
      boolean foundair = false;
      int enchantedSwordIndex = -1;
      int i;
      for (i = 0; i < 9; i++) {
        ItemStack itemStack = (ItemStack)mc.player.inventory.mainInventory.get(i);
        if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, itemStack) >= 32767) {
          enchantedSwordIndex = i;
          this.foundsword = true;
        } 
        if (!this.foundsword) {
          enchantedSwordIndex = -1;
          this.foundsword = false;
        } 
      } 
      if (enchantedSwordIndex != -1 && 
        mc.player.inventory.currentItem != enchantedSwordIndex) {
        mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(enchantedSwordIndex));
        mc.player.inventory.currentItem = enchantedSwordIndex;
        mc.playerController.updateController();
      } 
      if (enchantedSwordIndex == -1 && mc.player.openContainer != null && mc.player.openContainer instanceof net.minecraft.inventory.ContainerHopper && mc.player.openContainer.inventorySlots != null && !mc.player.openContainer.inventorySlots.isEmpty()) {
        for (i = 0; i < 5; i++) {
          if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, ((Slot)mc.player.openContainer.inventorySlots.get(0)).inventory.getStackInSlot(i)) >= 32767) {
            enchantedSwordIndex = i;
            break;
          } 
        } 
        if (enchantedSwordIndex == -1)
          return; 
        if (enchantedSwordIndex != -1)
          for (i = 0; i < 9; i++) {
            ItemStack itemStack = (ItemStack)mc.player.inventory.mainInventory.get(i);
            if (itemStack.getItem() instanceof net.minecraft.item.ItemAir) {
              if (mc.player.inventory.currentItem != i) {
                mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(i));
                mc.player.inventory.currentItem = i;
                mc.playerController.updateController();
              } 
              foundair = true;
              break;
            } 
          }  
        if (foundair || checkEnchants())
          mc.playerController.windowClick(mc.player.openContainer.windowId, enchantedSwordIndex, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player); 
      } 
    } 
    for (Entity entity : mc.world.loadedEntityList) {
      if (!(entity instanceof EntityLivingBase) || 
        entity == mc.player)
        continue; 
      if (mc.player.getDistance(entity) > this.range.getValDouble())
        continue; 
      if (((EntityLivingBase)entity).getHealth() <= 0.0F)
        continue; 
      if (!isTTK(mc.player.inventory.getCurrentItem()) && this.onlyttk.getValBoolean())
        continue; 
      if (!(entity instanceof EntityPlayer))
        continue; 
      if (Friends.isFriend(entity.getName()))
        continue; 
      if (this.Dticks >= (int)this.delay.getValDouble()) {
        mc.playerController.attackEntity((EntityPlayer)mc.player, entity);
        mc.player.swingArm(EnumHand.MAIN_HAND);
        this.Dticks = 0;
        return;
      } 
    } 
  }
  
  public void onEnable() {
    this.Dticks = 0;
  }
  
  public void onDisable() {
    this.Dticks = 0;
  }
  
  public boolean checkEnchants() {
    if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, mc.player.inventory.getCurrentItem()) == Short.valueOf((short)5).shortValue() || mc.player.inventory.getCurrentItem().getItem() instanceof net.minecraft.item.ItemPickaxe)
      return true; 
    return false;
  }
  
  public static boolean isTTK(ItemStack itemStack) {
    if (itemStack == null)
      return false; 
    if (itemStack.getTagCompound() == null)
      return false; 
    if (itemStack.getEnchantmentTagList().getTagType() == 0)
      return false; 
    NBTTagList list = (NBTTagList)itemStack.getTagCompound().getTag("ench");
    int i = 0;
    while (i < list.tagCount()) {
      NBTTagCompound compoundTag = list.getCompoundTagAt(i);
      if (compoundTag.getInteger("id") == 16) {
        if (compoundTag.getInteger("lvl") >= 16)
          return true; 
        break;
      } 
      i++;
    } 
    return false;
  }
}
