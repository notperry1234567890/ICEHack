//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.mixin.client;

import java.awt.Color;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.util.GuiUtil;
import me.fluffycq.icehack.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = {GuiScreen.class}, priority = 2147483647)
public class MixinGuiScreen {
  RenderItem itemRender = Minecraft.getMinecraft().getRenderItem();
  
  FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRenderer;
  
  @Inject(method = {"renderToolTip"}, at = {@At("HEAD")}, cancellable = true)
  public void renderToolTip(ItemStack stack, int x, int y, CallbackInfo info) {
    if (ICEHack.fevents.moduleManager.getModule("ShulkerViewer").isEnabled() && stack.getItem() instanceof net.minecraft.item.ItemShulkerBox) {
      NBTTagCompound tagCompound = stack.getTagCompound();
      if (tagCompound != null && tagCompound.hasKey("BlockEntityTag", 10)) {
        NBTTagCompound blockEntityTag = tagCompound.getCompoundTag("BlockEntityTag");
        if (blockEntityTag.hasKey("Items", 9)) {
          int outlineColor;
          info.cancel();
          NonNullList<ItemStack> nonnulllist = NonNullList.withSize(27, ItemStack.EMPTY);
          ItemStackHelper.loadAllItems(blockEntityTag, nonnulllist);
          GlStateManager.enableBlend();
          GlStateManager.disableRescaleNormal();
          RenderHelper.disableStandardItemLighting();
          GlStateManager.disableLighting();
          GlStateManager.disableDepth();
          int x1 = x + 12;
          int y1 = y - 12;
          int width = 150;
          int height = 60;
          this.itemRender.zLevel = 300.0F;
          Module m = ICEHack.fevents.moduleManager.getModule("ShulkerViewer");
          Module gui = ICEHack.fevents.moduleManager.getModule("ClickGUI");
          int bgColor = (new Color(16, 16, 16, (int)m.getSetting("Opacity").getValDouble())).getRGB();
          drawRect(x1, y1, (x1 + width), (y1 + height), bgColor);
          int textColor = (new Color((int)m.getSetting("Red").getValDouble(), (int)m.getSetting("Green").getValDouble(), (int)m.getSetting("Blue").getValDouble())).getRGB();
          if (gui.getSetting("Rainbow").getValBoolean()) {
            outlineColor = Color.getHSBColor((float)(System.currentTimeMillis() % 7500L) / 7500.0F, 0.8F, 0.8F).getRGB();
          } else {
            outlineColor = (new Color((int)gui.getSetting("Red").getValDouble(), (int)gui.getSetting("Green").getValDouble(), (int)gui.getSetting("Blue").getValDouble())).getRGB();
          } 
          GuiUtil.drawHorizontalLine(x1 - 1, x1 + width, y1 - 1, outlineColor);
          GuiUtil.drawHorizontalLine(x1 - 1, x1 + width, y1 + height - 1, outlineColor);
          GuiUtil.drawVerticalLine(x1 - 1, y1 - 1, y1 + height - 1, outlineColor);
          GuiUtil.drawVerticalLine(x1 + width, y1 - 1, y1 + height - 1, outlineColor);
          drawCenteredString(stack.getDisplayName(), x1 + width / 2, y1 + 2, textColor);
          GlStateManager.enableBlend();
          GlStateManager.enableAlpha();
          GlStateManager.enableTexture2D();
          GlStateManager.enableLighting();
          GlStateManager.enableDepth();
          RenderHelper.enableGUIStandardItemLighting();
          for (int i = 0; i < nonnulllist.size(); i++) {
            int iX = x + i % 9 * 16 + 11;
            int iY = y + i / 9 * 16 - 11 + 8;
            ItemStack itemStack = (ItemStack)nonnulllist.get(i);
            this.itemRender.renderItemAndEffectIntoGUI(itemStack, iX + 3, iY);
            this.itemRender.renderItemOverlayIntoGUI(this.fontRenderer, itemStack, iX + 3, iY, null);
          } 
          RenderHelper.disableStandardItemLighting();
          this.itemRender.zLevel = 0.0F;
          GlStateManager.enableLighting();
          GlStateManager.enableDepth();
          RenderHelper.enableStandardItemLighting();
          GlStateManager.enableRescaleNormal();
        } 
      } 
    } 
  }
  
  public void drawRect(float x, float y, float w, float h, int color) {
    float alpha = (color >> 24 & 0xFF) / 255.0F;
    float red = (color >> 16 & 0xFF) / 255.0F;
    float green = (color >> 8 & 0xFF) / 255.0F;
    float blue = (color & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.getInstance();
    BufferBuilder bufferbuilder = tessellator.getBuffer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
    bufferbuilder.pos(x, h, 0.0D).color(red, green, blue, alpha).endVertex();
    bufferbuilder.pos(w, h, 0.0D).color(red, green, blue, alpha).endVertex();
    bufferbuilder.pos(w, y, 0.0D).color(red, green, blue, alpha).endVertex();
    bufferbuilder.pos(x, y, 0.0D).color(red, green, blue, alpha).endVertex();
    tessellator.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  public void drawCenteredString(String text, int x, int y, int color) {
    this.fontRenderer.drawStringWithShadow(text, (x - this.fontRenderer.getStringWidth(text) / 2), y, color);
  }
}
