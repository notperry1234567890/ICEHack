//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.friends;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class Friends {
  public static ArrayList<String> tempFriends = new ArrayList<>();
  
  public Friends() {
    loadFriends();
  }
  
  public void createFriends() {
    File dir1 = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\friends\\");
    if (!dir1.exists())
      dir1.mkdir(); 
    File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\friends\\friendlist.txt");
    if (!file.exists())
      try {
        file.createNewFile();
      } catch (IOException e1) {
        e1.printStackTrace();
      }  
  }
  
  public void saveFriends() {
    BufferedWriter writer = null;
    File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\friends\\friendlist.txt");
    try {
      writer = new BufferedWriter(new FileWriter(file));
    } catch (IOException e1) {
      e1.printStackTrace();
    } 
    if (writer != null) {
      try {
        for (String s : tempFriends)
          writer.write(s + "\r\n"); 
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } else {
      System.out.println("[icehack] Could not add friend!");
    } 
    try {
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void addFriend(String username) {
    if (!isFriend(username.toLowerCase()))
      tempFriends.add(username.toLowerCase()); 
  }
  
  public void removeFriend(String username) {
    if (isFriend(username))
      tempFriends.remove(username.toLowerCase()); 
  }
  
  public static boolean isFriend(String name) {
    return tempFriends.contains(name.toLowerCase());
  }
  
  public void loadFriends() {
    try (BufferedReader br = new BufferedReader(new FileReader(new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\friends\\friendlist.txt")))) {
      String line;
      while ((line = br.readLine()) != null)
        tempFriends.add(line.toLowerCase()); 
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}
