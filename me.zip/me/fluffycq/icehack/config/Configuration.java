//Deobfuscated with https://github.com/PetoPetko/Minecraft-Deobfuscator3000 using mappings "1.12 stable mappings"!

package me.fluffycq.icehack.config;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import me.fluffycq.icehack.ICEHack;
import me.fluffycq.icehack.clickgui.element.Panel;
import me.fluffycq.icehack.clickgui.frame.Frame;
import me.fluffycq.icehack.module.Module;
import me.fluffycq.icehack.module.ModuleManager;
import me.fluffycq.icehack.setting.Setting;
import me.fluffycq.icehack.setting.SettingsManager;
import net.minecraft.client.Minecraft;

public class Configuration {
  public void createConfig(ModuleManager mmanager, SettingsManager mngr) {
    if (mmanager.moduleList != null)
      for (Module m : mmanager.moduleList) {
        File dir = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\");
        if (!dir.exists())
          dir.mkdir(); 
        File dir1 = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\");
        if (!dir1.exists())
          dir1.mkdir(); 
        File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\" + m.name + ".txt");
        if (!file.exists()) {
          try {
            file.createNewFile();
          } catch (IOException e1) {
            e1.printStackTrace();
          } 
          if (mngr.getSettingsByMod(m) != null)
            makeSettings(m, file); 
          continue;
        } 
        if (mngr.getSettingsByMod(m) != null)
          for (Setting s : ICEHack.setmgr.getSettingsByMod(m)) {
            if (!hasSettings(s))
              makeSetting(s, file); 
          }  
      }  
  }
  
  public void makeSetting(Setting s, File f) {
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(f, true));
    } catch (IOException e1) {
      e1.printStackTrace();
    } 
    if (writer != null) {
      if (s.isCheck())
        try {
          writer.append("bool:" + s.getName() + ":" + (s.getValBoolean() ? "true" : "false") + "\r\n");
        } catch (IOException e) {
          e.printStackTrace();
        }  
      if (s.isSlider())
        try {
          if (s.onlyInt()) {
            writer.append("sliderint:" + s.getName() + ":" + String.valueOf(s.getValDouble()) + "\r\n");
          } else if (!s.onlyInt()) {
            writer.append("sliderdouble:" + s.getName() + ":" + String.valueOf(s.getValDouble()) + "\r\n");
          } 
        } catch (IOException e) {
          e.printStackTrace();
        }  
      if (s.isCombo() && 
        s.getOptions() != null)
        try {
          String comboValue = Character.toUpperCase(s.getValString().toLowerCase().charAt(0)) + s.getValString().toLowerCase().substring(1);
          writer.append("combo:" + s.getName() + ":" + comboValue + "\r\n");
        } catch (IOException e) {
          e.printStackTrace();
        }  
      if (s.isBind())
        try {
          writer.append("key:Bind:" + String.valueOf(s.getKeyBind()) + "\r\n");
        } catch (IOException e) {
          e.printStackTrace();
        }  
    } 
    try {
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void makeSettings(Module m, File file) {
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(file));
    } catch (IOException e1) {
      e1.printStackTrace();
    } 
    if (writer != null) {
      try {
        writer.write("module:enabled:" + (m.getState() ? "true" : "false") + "\r\n");
      } catch (IOException e) {
        e.printStackTrace();
      } 
      for (Setting s : ICEHack.setmgr.getSettingsByMod(m)) {
        if (s.isCheck())
          try {
            writer.write("bool:" + s.getName() + ":" + (s.getValBoolean() ? "true" : "false") + "\r\n");
          } catch (IOException e) {
            e.printStackTrace();
          }  
        if (s.isSlider())
          try {
            if (s.onlyInt()) {
              writer.write("sliderint:" + s.getName() + ":" + String.valueOf(s.getValDouble()) + "\r\n");
            } else if (!s.onlyInt()) {
              writer.write("sliderdouble:" + s.getName() + ":" + String.valueOf(s.getValDouble()) + "\r\n");
            } 
          } catch (IOException e) {
            e.printStackTrace();
          }  
        if (s.isCombo() && 
          s.getOptions() != null)
          try {
            writer.write("combo:" + s.getName() + ":" + s.getValString() + "\r\n");
          } catch (IOException e) {
            e.printStackTrace();
          }  
        if (s.isBind())
          try {
            writer.write("key:Bind:" + String.valueOf(s.getParentMod().getKey()) + "\r\n");
          } catch (IOException e) {
            e.printStackTrace();
          }  
      } 
    } else {
      System.out.println("[icehack] Could not write Settings for Module " + m.name);
    } 
    try {
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public boolean hasSettings(Setting set) {
    boolean has = false;
    try (BufferedReader br = new BufferedReader(new FileReader(new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\" + (set.getParentMod()).name + ".txt")))) {
      String line;
      while ((line = br.readLine()) != null) {
        if (!line.contains(":"))
          continue; 
        if (line.contains(set.getName()))
          has = true; 
      } 
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } 
    return has;
  }
  
  public void saveSettings(ModuleManager mngr, SettingsManager smngr) {
    if (mngr.moduleList != null)
      for (Module m : mngr.moduleList) {
        File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\" + m.name + ".txt");
        PrintWriter pw = null;
        try {
          pw = new PrintWriter(file.getAbsolutePath());
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        } 
        if (pw != null) {
          pw.print("");
          pw.close();
        } 
        if (file.exists() && 
          smngr.getSettingsByMod(m) != null)
          makeSettings(m, file); 
      }  
  }
  
  public void loadSettings(Module m) {
    if (existingSettings(m))
      try (BufferedReader br = new BufferedReader(new FileReader(new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\" + m.name + ".txt")))) {
        String line;
        while ((line = br.readLine()) != null) {
          if (!line.contains(":"))
            continue; 
          if (line.split(":")[0].equalsIgnoreCase("module"))
            m.setState(Boolean.valueOf(line.split(":")[2]).booleanValue()); 
          for (Setting s : ICEHack.setmgr.getSettingsByMod(m)) {
            if (s.getName().equalsIgnoreCase(line.split(":")[1].split(":")[0])) {
              if (s.isCheck())
                s.setValBoolean(Boolean.valueOf(line.split(":")[2]).booleanValue()); 
              if (s.isSlider())
                if (s.onlyInt()) {
                  s.setValDouble(Double.valueOf(line.split(":")[2]).doubleValue());
                } else if (!s.onlyInt()) {
                  s.setValDouble(Double.valueOf(line.split(":")[2]).doubleValue());
                }  
              if (s.isCombo())
                s.setValString(line.split(":")[2]); 
              if (s.isBind())
                s.getParentMod().setKey(Integer.valueOf(line.split(":")[2]).intValue()); 
            } 
          } 
        } 
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      }  
  }
  
  public boolean existingSettings(Module module) {
    File fileSettings = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\settings\\" + module.name + ".txt");
    if (fileSettings.exists())
      return true; 
    return false;
  }
  
  public boolean checkPanelDir() {
    File panelDir = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\");
    if (panelDir.exists())
      return true; 
    return false;
  }
  
  public boolean checkModuleListDir() {
    File arrayDir = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\arraylist\\");
    if (arrayDir.exists())
      return true; 
    return false;
  }
  
  public void initPanels() {
    File panelDir = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\");
    if (!panelDir.exists())
      panelDir.mkdir(); 
    if (ICEHack.clickgui.panels != null)
      for (Panel p : ICEHack.clickgui.panels) {
        File panelFile = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\" + p.title + ".txt");
        if (!panelFile.exists()) {
          try {
            panelFile.createNewFile();
          } catch (IOException e) {
            e.printStackTrace();
          } 
          BufferedWriter writer = null;
          try {
            writer = new BufferedWriter(new FileWriter(panelFile));
          } catch (IOException e1) {
            e1.printStackTrace();
          } 
          if (writer != null) {
            try {
              writer.write("x:" + String.valueOf(p.x) + "\r\n");
              writer.write("y:" + String.valueOf(p.y) + "\r\n");
              writer.write("extended:" + String.valueOf(p.extended) + "\r\n");
            } catch (IOException e) {
              e.printStackTrace();
            } 
            try {
              writer.close();
            } catch (IOException e) {
              e.printStackTrace();
            } 
          } 
        } 
        p.addModules();
      }  
  }
  
  public void initFrames() {
    File arrayListDir = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\frames\\");
    if (!arrayListDir.exists())
      arrayListDir.mkdir(); 
    if (ICEHack.clickgui.frames != null)
      for (Frame p : ICEHack.clickgui.frames) {
        File arrayFile = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\frames\\" + p.title + ".txt");
        if (!arrayFile.exists()) {
          try {
            arrayFile.createNewFile();
          } catch (IOException e) {
            e.printStackTrace();
          } 
          BufferedWriter writer = null;
          try {
            writer = new BufferedWriter(new FileWriter(arrayFile));
          } catch (IOException e1) {
            e1.printStackTrace();
          } 
          if (writer != null) {
            try {
              writer.write("x:" + String.valueOf(p.x) + "\r\n");
              writer.write("y:" + String.valueOf(p.y) + "\r\n");
              writer.write("extended:" + String.valueOf(p.extended) + "\r\n");
            } catch (IOException e) {
              e.printStackTrace();
            } 
            try {
              writer.close();
            } catch (IOException e) {
              e.printStackTrace();
            } 
          } 
        } 
      }  
  }
  
  public void saveFrame(Frame p) {
    File panelFile = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\frames\\" + p.title + ".txt");
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(panelFile));
    } catch (IOException e1) {
      e1.printStackTrace();
    } 
    if (writer != null) {
      try {
        writer.write("x:" + String.valueOf(p.x) + "\r\n");
        writer.write("y:" + String.valueOf(p.y) + "\r\n");
        writer.write("extended:" + String.valueOf(p.extended) + "\r\n");
      } catch (IOException e) {
        e.printStackTrace();
      } 
      try {
        writer.close();
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void savePanel(Panel p) {
    File panelFile = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\" + p.title + ".txt");
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(panelFile));
    } catch (IOException e1) {
      e1.printStackTrace();
    } 
    if (writer != null) {
      try {
        writer.write("x:" + String.valueOf(p.x) + "\r\n");
        writer.write("y:" + String.valueOf(p.y) + "\r\n");
        writer.write("extended:" + String.valueOf(p.extended) + "\r\n");
      } catch (IOException e) {
        e.printStackTrace();
      } 
      try {
        writer.close();
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void loadPanels() {
    if (ICEHack.clickgui.panels != null)
      for (Panel p : ICEHack.clickgui.panels) {
        try (BufferedReader br = new BufferedReader(new FileReader(new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\" + p.title + ".txt")))) {
          String line;
          while ((line = br.readLine()) != null) {
            if (!line.contains(":"))
              continue; 
            if (line.split(":")[0].equalsIgnoreCase("x"))
              p.x = Integer.valueOf(line.split(":")[1]).intValue(); 
            if (line.split(":")[0].equalsIgnoreCase("y"))
              p.y = Integer.valueOf(line.split(":")[1]).intValue(); 
            if (line.split(":")[0].equalsIgnoreCase("extended"))
              p.extended = Boolean.valueOf(line.split(":")[1]).booleanValue(); 
          } 
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        } catch (IOException e) {
          e.printStackTrace();
        } 
        p.addModules();
      }  
  }
  
  public void loadFrames() {
    if (ICEHack.clickgui.frames != null)
      for (Frame p : ICEHack.clickgui.frames) {
        try (BufferedReader br = new BufferedReader(new FileReader(new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\frames\\" + p.title + ".txt")))) {
          String line;
          while ((line = br.readLine()) != null) {
            if (!line.contains(":"))
              continue; 
            if (line.split(":")[0].equalsIgnoreCase("x"))
              p.x = Integer.valueOf(line.split(":")[1]).intValue(); 
            if (line.split(":")[0].equalsIgnoreCase("y"))
              p.y = Integer.valueOf(line.split(":")[1]).intValue(); 
            if (line.split(":")[0].equalsIgnoreCase("extended"))
              p.extended = Boolean.valueOf(line.split(":")[1]).booleanValue(); 
          } 
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        } catch (IOException e) {
          e.printStackTrace();
        } 
      }  
  }
  
  public void savePanels() {
    if (ICEHack.clickgui.panels != null)
      for (Panel p : ICEHack.clickgui.panels) {
        File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\gui\\" + p.title + ".txt");
        PrintWriter pw = null;
        try {
          pw = new PrintWriter(file.getAbsolutePath());
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        } 
        if (pw != null) {
          pw.print("");
          pw.close();
        } 
        if (file.exists())
          savePanel(p); 
      }  
  }
  
  public void saveFrames() {
    if (ICEHack.clickgui.frames != null)
      for (Frame p : ICEHack.clickgui.frames) {
        File file = new File((Minecraft.getMinecraft()).gameDir.getAbsolutePath(), "\\ICEHack\\frames\\" + p.title + ".txt");
        PrintWriter pw = null;
        try {
          pw = new PrintWriter(file.getAbsolutePath());
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        } 
        if (pw != null) {
          pw.print("");
          pw.close();
        } 
        if (file.exists())
          saveFrame(p); 
      }  
  }
}
