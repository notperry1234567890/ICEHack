package me.zero.alpine.type;

public enum EventState {
  PRE, POST;
}
